<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
 <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'menu.php';
 ?><br>
    <div class="container card" style="background-color: #ffffff">
        <h4><b><p style="color:red;">Edit Tour Places</p></b></h4>
        <form name='f1' method='post' action="#" enctype="">
    	    <div class="container">
<?php 
	include 'sqlconnections.php';
	$qry="select place_id,place_name,description,tour_pic,address,latitute,longitute from tour_places where place_id=?";
	$conn->set_charset("utf8mb4");

	$stmt =$conn->prepare($qry);
	$stmt->bind_param("s",$_REQUEST['place_id']);
	$stmt->execute();
	$rs = $stmt->get_result();
	if (mysqli_num_rows($rs) > 0) 
	{
		$i=1;
		while($row = mysqli_fetch_assoc($rs))
		{
			echo "<div class='row'>";
			echo "<div class='col-sm-3'>";
			echo "<label class='form-check-label'>Place Id</label>";
			echo "<input type='text' class='form-control' name='place_id' value='".$row['place_id']."'>";
			echo "</div>";
			echo "<div class='col-sm-3'>";
			echo "<label class='form-check-label'>Place Name</label>";
			echo "<input type='text' class='form-control' name='place_name' value='".$row['place_name']."'>";
			echo "</div>";
			echo "<div class='col-sm-3'>";
			echo "<label class='form-check-label'>Description</label>";
			echo "<input type='text' class='form-control' name='description' value='".$row['description']."'>";
			echo "</div>";
			
			echo "<div class='col-sm-3'>";
			echo "<label class='form-check-label'>Address</label>";
			echo "<input type='text' class='form-control' name='address' value='".$row['address']."'>";
			echo "</div>";
			echo "<div class='col-sm-3'>";
			echo "<label class='form-check-label'>Latitute</label>";
			echo "<input type='text' class='form-control' name='latitute' value='".$row['latitute']."'>";
			echo "</div>";
			echo "<div class='col-sm-3'>";
			echo "<label class='form-check-label'>Longitute</label>";
			echo "<input type='text' class='form-control' name='longitute' value='".$row['longitute']."'>";
			echo "</div>";
	echo "</div><hr></hr>";
		}
}
else
{

	echo "<h1>Records Not Found</h1>";
}

?>
            <br>
    	    <button type="submit" name='submit' class="btn btn-default btn-outline-dark">Update</button>
       </form>
       
       <form name='f2' method='post' action='#'>
            			
	<?php
			if(isset($_REQUEST['submit']))
			{
	$updateqry="update tour_places set  place_name='".$_REQUEST['place_name']."' , description='".$_REQUEST['description']."' , address='".$_REQUEST['address']."' , latitute='".$_REQUEST['latitute']."' , longitute='".$_REQUEST['longitute']."'  where place_id='".$_REQUEST['place_id']."'";
			
	if (mysqli_query($conn, $updateqry))
			
	{
			
		echo "<script language='javascript'>window.alert('Record updated successfully');window.location='view_tour_manage.php';</script>";
			
	}
			
}
mysqli_close($conn);
?>
       </form>
    </div>
</body>
</html>
