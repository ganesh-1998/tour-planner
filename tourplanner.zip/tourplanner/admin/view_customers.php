<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'menu.php';
 ?><br>
<div class="container card" style="background-color: #ffffff">
    <h4><b><p style="color:red;">Customers </p></b></h4>
    
<?php 
	include 'sqlconnections.php';
?>
   
<?php
$qry="select customer_name,address,zipcode,mobile,email,pic,password,registerDate from customers";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	echo "<br><table class='table table-bordered display' id='table_id'>";
	echo "<thead class='thead-light'>";
	echo "<tr>";
	echo "<th>customer_name</th>";
	echo "<th>address</th>";
	echo "<th>zipcode</th>";
	echo "<th>mobile</th>";
	echo "<th>email</th>";
	echo "<th>pic</th>";
	echo "<th>password</th>";
	echo "<th>registerDate</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	while($row = mysqli_fetch_assoc($rs))
		{
	echo "<tr>";
		 echo "<td>".$row['customer_name']."</td>";
		 echo "<td>".$row['address']."</td>";
		 echo "<td>".$row['zipcode']."</td>";
		 echo "<td>".$row['mobile']."</td>";
		 echo "<td>".$row['email']."</td>";
		 echo "<td><img src='../uploads/".$row['pic']."' width='100px' height='100px'></img></td>";
		 echo "<td>".$row['password']."</td>";
		 echo "<td>".$row['registerDate']."</td>";
	echo "</tr>";
		}
	echo "
	</tbody>";
	echo "<thead class='thead-light'>";
	echo "<tr>";
	echo "<th>customer_name</th>";
	echo "<th>address</th>";
	echo "<th>zipcode</th>";
	echo "<th>mobile</th>";
	echo "<th>email</th>";
	echo "<th>pic</th>";
	echo "<th>password</th>";
	echo "<th>registerDate</th>";
	echo "</tr>";
	echo "</thead></table>
</div>";
}
else
{

	echo "<h5>Customers Records Not Found</h5>";
}
mysqli_close($conn);
?>
   </div>
   <br>
</div>

<script>
		$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
		
</body>
</html>
