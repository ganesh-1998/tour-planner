	<?php 
session_start();
include '../sqlconnections.php';

$conn->set_charset("utf8mb4");
$qry="delete from tour_package_places where tour_place_id=?";		
$stmt =$conn->prepare($qry);
$stmt->bind_param("s", $_REQUEST['tour_place_id']); 
$stmt->execute();
if($stmt->affected_rows > 0)
{		
	echo "<script language='javascript'>window.alert('Record deleted successfully');window.location='view_package.php';</script>";
}
mysqli_close($conn);
?>