<?php 
session_start();
include '../sqlconnections.php';
if(isset($_REQUEST['place_name']))
	$place_name=$_REQUEST['place_name'];
else
	$place_name='null';

if(isset($_REQUEST['description']))
	$description=$_REQUEST['description'];
else
	$description='null';
if (!is_dir('uploads')) {mkdir('uploads');}
if(isset($_FILES['tour_pic']))
{
	$rndno=rand();
	$tour_pic=$rndno.$_FILES['tour_pic']['name'];



	$errors= array();
	$file_name = $rndno.$_FILES['tour_pic']['name'];
	$file_size =$_FILES['tour_pic']['size'];
	$file_tmp =$_FILES['tour_pic']['tmp_name'];
	$file_type=$_FILES['tour_pic']['type'];
	$ss=explode('.',$_FILES['tour_pic']['name']);
	$file_ext=strtolower($ss[count($ss)-1]);/* // $file_ext=strtolower(end(explode('.',$_FILES['tour_pic']['name']))); 
	$expensions= array('jpeg','jpg','png');
	if(in_array($file_ext,$expensions)=== false)
		{
			$errors[]='extension not allowed, please choose a JPEG or PNG file.';
		} */
if($file_size > 2097152)
{
	$errors[]='File size must be excately 2 MB';
}
if(empty($errors)==true)
{
	move_uploaded_file($file_tmp,'uploads/'.$file_name);
}
else
{

	print_r($errors);
}
}
else
	$tour_pic='null';

if(isset($_REQUEST['address']))
	$address=$_REQUEST['address'];
else
	$address='null';

if(isset($_REQUEST['latitute']))
	$latitute=$_REQUEST['latitute'];
else
	$latitute='null';

if(isset($_REQUEST['longitute']))
	$longitute=$_REQUEST['longitute'];
else
	$longitute='null';

$conn->set_charset("utf8mb4");
$qry="insert into tour_places(place_name,description,tour_pic,address,latitute,longitute) values(?,?,?,?,?,?)";
$stmt =$conn->prepare($qry);
$stmt->bind_param("ssssss", $place_name,$description,$tour_pic,$address,$latitute,$longitute); 
$stmt->execute();
if($stmt->affected_rows > 0)
{
	 echo "<script language='javascript'>window.location='add_tour_places.php?msg=Record Added';</script>";
}
else 
{
	echo "<script language='javascript'>window.location='add_tour_places.php?msg=Record Not Added';</script>";
}
mysqli_close($conn);
?>