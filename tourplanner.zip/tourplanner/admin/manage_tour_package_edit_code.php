<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
   <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'menu.php';
 ?>
 <br>
    <div class="container card" style="background-color: #ffffff">
        <h4><b><p style="color:red;">Edit Tour Package</p></b></h4>
        <form name='f1' method='post' action="#" enctype="">
    	    
                	<?php 
		
include 'sqlconnections.php';
			
			
			
$qry="select package_id,package_name,package_description,package_pic,price,start_date,end_date from tour_package where package_id=		'".$_REQUEST['package_id']."'";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	$i=1;
	while($row = mysqli_fetch_assoc($rs))
		{
		echo "<div class='row'>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Package Id</label>";
		echo "<input type='text' class='form-control' name='package_id' value='".$row['package_id']."' readonly>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Package Name</label>";
		echo "<input type='text' class='form-control' name='package_name' value='".$row['package_name']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Package Description</label>";
		echo "<input type='text' class='form-control' name='package_description' value='".$row['package_description']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Price</label>";
		echo "<input type='text' class='form-control' name='price' value='".$row['price']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Start Date</label>";
		echo "<input type='text' class='form-control' name='start_date' value='".$row['start_date']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>End Date</label>";
		echo "<input type='text' class='form-control' name='end_date' value='".$row['end_date']."'>";
		echo "</div>";
	echo "</div><hr></hr>";
		}
}

?>
            <br>
    	    <button type="submit" name='submit' class="btn btn-default btn-outline-dark">Update</button>
			<br>
       </form>
       
       <form name='f2' method='post' action='#'>
            			
	<?php
	if(isset($_REQUEST['submit']))
	{
		$updateqry="update tour_package set package_name='".$_REQUEST['package_name']."' , package_description='".$_REQUEST['package_description']."' , price='".$_REQUEST['price']."' , start_date='".$_REQUEST['start_date']."' , end_date='".$_REQUEST['end_date']."'  where package_id='".$_REQUEST['package_id']."'";;
		if (mysqli_query($conn, $updateqry))
		{
		echo "<script language='javascript'>window.alert('Record updated successfully');window.location='manage_tour_package.php';</script>";
		}
	}
	mysqli_close($conn);
?>
       </form>
	   <br>
    </div>
</body>
</html>
