<?php 
session_start();
include '../sqlconnections.php';
if(isset($_REQUEST['tour_place_id'])){
	$tour_place_id=$_REQUEST['tour_place_id'];
	$s=explode("-", $tour_place_id);
	$tour_place_id=$s[0];
}
else
	$tour_place_id='null';

if(isset($_REQUEST['hotel_id'])){
	$hotel_id=$_REQUEST['hotel_id'];
	$s=explode("-", $hotel_id);
	$hotel_id=$s[0];
}
else
	$hotel_id='null';

if(isset($_REQUEST['guide_id'])){
	$guide_id=$_REQUEST['guide_id'];
	$s=explode("-", $guide_id);
	$guide_id=$s[0];
}
else
	$guide_id='null';


$conn->set_charset("utf8mb4");
$qry="insert into tour_package_guide_hotel(tour_place_id,hotel_id,guide_id) values(?,?,?)";
$stmt =$conn->prepare($qry);
$stmt->bind_param("sss", $tour_place_id,$hotel_id,$guide_id); 
$stmt->execute();
if($stmt->affected_rows > 0)
{	 
	echo "<script language='javascript'>window.location='add_guide_hotel.php?msg=Record Added';</script>";
}
else 
{
	echo "<script language='javascript'>window.location='add_guide_hotel.php?msg=Record Not Added';</script>";
}
mysqli_close($conn);
?>