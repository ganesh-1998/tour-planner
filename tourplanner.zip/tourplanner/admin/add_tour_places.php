<?php session_start(); ?>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
	include 'menu.php';
 ?>
<section ><br>
    <div class="container card" style="background-color: #ffffff;width:50%">
        <div class="row">
           
            <div class="col-md-12">
              <center>  <h4><b><p style="color:red;">Add Tour Places</p></b></h4> </center>
               <form name='f1' method='post' action="add_tour_places_code.php" enctype="multipart/form-data">
   
					
<div class='row'>
	<div class='col-md-6'>
	<b>	<label for='place_name'>Place Name</label></b>
		<input type='text' class='form-control' id='place_name' placeholder='Place Name' name='place_name' required >
	</div>
	<div class='col-md-6'>
		<b><label for='description'>Description</label></b>
		<textarea rows='3' class='form-control' id='description' placeholder='Description' name='description' required ></textarea>
	</div>
</div>
<div class='row'>
	<div class='col-md-6'>
		<b><label for='tour_pic'>Tour Picture</label></b>
		<input type='file' class='form-control' id='tour_pic' placeholder='Tour Pic' name='tour_pic' required >
	</div>
	<div class='col-md-6'>
		<b><label for='address'>Address</label></b>
		<textarea rows='3' class='form-control' id='address' placeholder='Address' name='address' required ></textarea>
	</div>
</div>
<div class='row'>
	<div class='col-md-6'>
	<b>	<label for='latitute'>Latitute</label></b>
		<input type='text' class='form-control' id='latitute' placeholder='Latitute' name='latitute' required >
	</div>
	<div class='col-md-6'>
	<b>	<label for='longitute'>Longitute</label></b>
		<input type='text' class='form-control' id='longitute' placeholder='Longitute' name='longitute' required >
	</div>
</div>	
					<br>
                    <div class="form-row">
                           <input  type="submit" name="submit" class="btn btn-outline-dark" value="Add Tour">
						   <br>
						   <?php
							if(isset($_REQUEST['msg'])){
								echo "<h4 class='text-success'>".$_REQUEST['msg']."</h4>";
							}
						   ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
		
</body>
</html>
