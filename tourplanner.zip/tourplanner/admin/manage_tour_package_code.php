	<?php 
session_start();
include '../sqlconnections.php';		 

			
			
			
$qry="delete from tour_package where package_id=		'".$_REQUEST['package_id']."'";			
	if (mysqli_query($conn, $qry))
			
	{
			
		echo "<script language='javascript'>window.alert('Record deleted successfully');window.location='manage_tour_package.php';</script>";
			
	}
			
	mysqli_close($conn);
			
?>