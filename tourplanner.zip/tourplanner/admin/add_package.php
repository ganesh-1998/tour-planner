<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
	include 'menu.php';
	include 'sqlconnections.php';
 ?><br>
   <div class="container card" style="background-color: #ffffff;width:50%">
      <center>  <h4><b><p style="color:red;">Add Tour Package Places</p></b></h4> </center>
  <form name='f1' method='post' action="add_package_code.php" enctype="multipart/form-data">
	
	<div class="row">
		<div class="col-sm-6">
			<img src="images/tp3.jpg" width="100%" alt="add image path">
		</div>
		
		<div class="col-sm-6">
		 
<div class='row'>
	<div class='col-md-12'>
		<b><label for='package_id'>Package Id</label></b>
		<?php
		$qry="select package_id,package_name from tour_package order by package_id";
		//echo $qry;
		?>
		<select name='package_id' class='form-control'>
		<?php
			
			$rs=mysqli_query($conn,$qry);
			while($row=mysqli_fetch_assoc($rs)){
				echo "<option>".$row['package_id']."-".$row['package_name']."</option>";
			}
		?>
		</select>
	</div><div>
	<div class='col-md-12'>
		<b><label for='place_id'>Place Id</label></b>
		
		<select name='place_id' class='form-control'>
		<?php
			$qry="select place_id,place_name from tour_places order by place_id";
			$rs=mysqli_query($conn,$qry);
			while($row=mysqli_fetch_assoc($rs)){
				echo "<option>".$row['place_id']."-".$row['place_name']."</option>";
			}
		?>
		</select>
	</div></div>
</div>

		<br>
	<button type="submit" class="btn btn-default btn-outline-dark">Add Package</button>
	<br>
	<?php
							if(isset($_REQUEST['msg'])){
								echo "<h4 class='text-success'>".$_REQUEST['msg']."</h4>";
							}
						   ?>
		</div>
		<br>
		
	
	</div>
        
       
   
   </form>
</div>
		
		
</body>
</html>
