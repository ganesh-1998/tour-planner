


<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
    
      <img src="images\l4.jpg" alt="Logo" style="width:40px;" class="rounded-pill">
      <a class="navbar-brand" href="#" ><span class='text-primary'>Tour Planner</span></a>
    </a>
  </div>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
          	        
	            <li class='nav-item'><a href='admin_main.php' class='nav-link' class='active'>Home</a></li>	        
	            <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" href="#">Tour Places<span class="caret"></span></a>
          <ul class="dropdown-menu">	        
	            <li class='nav-item'><a href='add_tour_places.php' class="dropdown-item" >Add</a></li>	        
	            <li class='nav-item'><a href='view_tour_manage.php' class="dropdown-item" >Manage</a></li>                
                </ul>
            </li>	        
	            <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" href="#">Tour Package<span class="caret"></span></a>
          <ul class="dropdown-menu">	        
	            <li class='nav-item'><a href='add_tour_package.php' class="dropdown-item" >Add</a></li>	        
	            <li class='nav-item'><a href='manage_tour_package.php' class="dropdown-item" >Manage</a></li>                
                </ul>
            </li>	        
	            <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" href="#">Tour Package Placess<span class="caret"></span></a>
          <ul class="dropdown-menu">	        
	            <li class='nav-item'><a href='add_package.php' class="dropdown-item" >Add</a></li>	        
	            <li class='nav-item'><a href='view_package.php' class="dropdown-item" >Manage</a></li>                
                </ul>
            </li>	        
	            <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" href="#">Tour Package Guide Hotel<span class="caret"></span></a>
          <ul class="dropdown-menu">	        
	            <li class='nav-item'><a href='add_guide_hotel.php' class="dropdown-item" >Add</a></li>	        
	            <li class='nav-item'><a href='view_guide_hotel.php' class="dropdown-item" >Manage</a></li>                
                </ul>
            </li>	        
	            <li class='nav-item'><a href='view_feedbacks.php' class='nav-link' >Feedbacks</a></li>	        
	            <li class='nav-item'><a href='view_customers.php' class='nav-link' >Customers</a></li>	        
	            <li class='nav-item'><a href='view_payments.php' class='nav-link' >Payments</a></li>	        
	            <li class='nav-item'><a href='../home.php' class='nav-link' >Logout</a></li> 
      </ul>
      
    </div>
  </div>
</nav>
<br><br><br>