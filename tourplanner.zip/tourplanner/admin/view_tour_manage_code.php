<?php 
session_start();
include '../sqlconnections.php';
$conn->set_charset("utf8mb4");
$qry="delete from tour_places where place_id=?";
$stmt =$conn->prepare($qry);
$stmt->bind_param("s", $_REQUEST['place_id']); 
$stmt->execute();
if($stmt->affected_rows > 0)
{			
		echo "<script language='javascript'>window.alert('Record deleted successfully');window.location='view_tour_manage.php';</script>";
			
}
mysqli_close($conn);
?>