<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'menu.php';
include 'sqlconnections.php';
 ?>

<br>
  
  <div class="container card" style="background-color: #ffffff;width:60%">
      <center>  <h4><b><p style="color:red;">Add Package Guide Hotel </p></b></h4> </center>
  <form name='f1' method='post' action="add_guide_hotel_code.php" enctype="multipart/form-data">
	
	<div class="row">
		<div class="col-sm-6">
			<img src="images/tp4.png" width="100%" alt="add image path">
		</div>
		
		<div class="col-sm-6">
		 
<div class='row'>
	<div class='col-md-12'>
	<b>	<label for='tour_place_id'>Tour Place Id</label></b>
		<select name='tour_place_id' class='form-control'>
		<?php
			$qry="select place_id,place_name from tour_places order by place_id";
			$rs=mysqli_query($conn,$qry);
			while($row=mysqli_fetch_assoc($rs)){
				echo "<option>".$row['place_id']."-".$row['place_name']."</option>";
			}
		?>
		</select>


	</div><div>
	<div class='col-md-12'>
		<b><label for='hotel_id'>Hotel Id</label></b>
		
		<select name='hotel_id' class='form-control'>
		<?php
			$qry="select hotel_id,hotel_name from hotel order by hotel_id";
			$rs=mysqli_query($conn,$qry);
			while($row=mysqli_fetch_assoc($rs)){
				echo "<option>".$row['hotel_id']."-".$row['hotel_name']."</option>";
			}
		?>
		</select>
	</div></div>
</div>
<div class='row'>
	<div class='col-md-12'>
	<b>	<label for='guide_id'>Guide Id</label></b>
		<select name='guide_id' class='form-control'>
		<?php
			$qry="select guide_id,guide_name from guides order by guide_id";
			$rs=mysqli_query($conn,$qry);
			while($row=mysqli_fetch_assoc($rs)){
				echo "<option>".$row['guide_id']."-".$row['guide_name']."</option>";
			}
		?>
		</select>

	</div>
</div>

		<br>
		<button type="submit" class="btn btn-default btn-outline-dark">Add Guide to Hotel</button>
		<br>
		<?php
							if(isset($_REQUEST['msg'])){
								echo "<h4 class='text-success'>".$_REQUEST['msg']."</h4>";
							}
						   ?>
		</div>
		<br>
	
	</div>
            
   
   </form>
</div>
		
		
</body>
</html>
