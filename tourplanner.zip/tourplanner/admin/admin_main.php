<!DOCTYPE html>
<html lang="en">
<head>
   <?php
	include 'files/files.php';
  ?>
  
</head>
<body>
<?php 
include 'menu.php';
 ?>

<div class="jumbotron">
  <div class="container text-center"><br>
     <h3><b><p style="color:Dark;">  Administration  </p></b></h3>  
    
    
  </div>
</div>
  

<div class="container-fluid bg-3 text-center">    
   <div class="row">
    <div class="col-sm-12">
      <img src="images/aa.jpg" class="img-responsive center" style="width:50%" alt="Image" >
    </div>
   
  </div>
</div>
</body>
</html>
