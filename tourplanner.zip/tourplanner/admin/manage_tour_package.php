<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
   <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'menu.php';
 ?><br>
<div class="container card" style="background-color: #ffffff"><br>
    <h4><b><p style="color:red;">Tour Packages</p></b></h4>
 
        <?php 
	include 'sqlconnections.php';
?>

<?php
$qry="select package_id,package_name,package_description,package_pic,price,start_date,end_date from tour_package";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	echo "<table class='table table-sm table-striped' id='table_id'>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th><th></th>";
	echo "<th>Package Id</th>";
	echo "<th>Package Name</th>";
	echo "<th>Package Description</th>";
	echo "<th>Package Pic</th>";
	echo "<th>Price</th>";
	echo "<th>Start Date</th>";
	echo "<th>End Date</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	while($row = mysqli_fetch_assoc($rs))
		{			
			
	echo "<tr><th><A class='btn btn-sm btn-success' href='manage_tour_package_edit_code.php?package_id=".$row['package_id']."'><i class='fa fa-pencil-square-o' aria-hidden='true'></i></th> <th><A class='btn btn-sm btn-danger' href='manage_tour_package_code.php?package_id=".$row['package_id']."'> <i class='fa fa-trash' aria-hidden='true'></i></A></th>";
		 echo "<td>".$row['package_id']."</td>";
		 echo "<td>".$row['package_name']."</td>";
		 echo "<td>".$row['package_description']."</td>";
		 echo "<td><img src='uploads/".$row['package_pic']."' width='100px' height='100px'></img></td>";
		 echo "<td>".$row['price']."</td>";
		 echo "<td>".$row['start_date']."</td>";
		 echo "<td>".$row['end_date']."</td>";
	echo "</tr>";
		}
	echo "
	</tbody>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th><th></th>";
	echo "<th>Package Id</th>";
	echo "<th>Package Name</th>";
	echo "<th>Package Description</th>";
	echo "<th>Package Pic</th>";
	echo "<th>Price</th>";
	echo "<th>Start Date</th>";
	echo "<th>End Date</th>";
	echo "</tr>";
	echo "</thead></table>
</div>";
}
else
{
	echo "<h3>Records Not Found</h3>";
}

mysqli_close($conn);
?>
<br>
</div>

<script>
		$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
		
</body>
</html>
