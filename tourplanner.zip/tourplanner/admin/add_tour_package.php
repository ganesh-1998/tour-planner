<?php session_start(); ?>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>

</head>
<body >
<?php 
include 'menu.php';
 ?>
<section ><br>
    <div class="container card" style="background-color: #ffffff;width:60%">
        <div class="row">
           
            <div class="col-md-12"><br>
                <center>  <h4><b><p style="color:red;">Add Tour Package Places</p></b></h4> </center>
               <form name='f1' method='post' action="add_tour_package_code.php" enctype="multipart/form-data">
   
					
<div class='row'>
	<div class='col-md-6'>
		<b><label for='package_name'>Tour Package Name</label></b>
		<textarea rows='3' class='form-control' id='package_name' placeholder='Package Name' name='package_name' required ></textarea>
	</div>
	<div class='col-md-6'>
	<b>	<label for='package_description'>Package Description</label></b>
		<textarea rows='3' class='form-control' id='package_description' placeholder='Package Description' name='package_description' required ></textarea>
	</div>
</div>
<div class='row'>
	<div class='col-md-6'>
		<b><label for='package_pic'>Package Picture</label></b>
		<input type='file' class='form-control' id='package_pic' placeholder='Package Pic' name='package_pic' required >
	</div>
	<div class='col-md-6'>
		<b><label for='price'>Price</label></b>
		<input type='text' class='form-control' id='price' placeholder='Price' name='price' required >
	</div>
</div>
<div class='row'>
	<div class='col-md-6'>
	<b>	<label for='start_date'>Start Date</label></b>
		<input type='date' class='form-control' id='start_date' placeholder='Start Date' name='start_date' required >
	</div>
	<div class='col-md-6'>
		<b><label for='end_date'>End Date</label></b>
		<input type='date' class='form-control' id='end_date' placeholder='End Date' name='end_date' required >
	</div>
</div>	
					<br>
                    <div class="form-row">
                           <input  type="submit" name="submit" class="btn btn-outline-dark" value="Add Package">
						   <br>
						   <?php
							if(isset($_REQUEST['msg'])){
								echo "<h4 class='text-success'>".$_REQUEST['msg']."</h4>";
							}
						   ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
		
</body>
</html>
