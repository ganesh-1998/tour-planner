<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'menu.php';
 ?><br>
<div class="container card" style="background-color: #ffffff">
   <h4><b><p style="color:purple;">Tours</p></b></h4>
       <?php 
	include 'sqlconnections.php';
?>
        <br>
  
   <div class="container" style='margin-top:-40px'>
<?php
$qry="select place_id,place_name,description,tour_pic,address,latitute,longitute from tour_places";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	echo "<table class='table table-sm table-striped' id='table_id'>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th><th></th>";
	echo "<th>Place Id</th>";
	echo "<th>Place Name</th>";
	echo "<th>Description</th>";
	echo "<th>Tour Pic</th>";
	echo "<th>Address</th>";
	echo "<th>Latitute</th>";
	echo "<th>Longitute</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	while($row = mysqli_fetch_assoc($rs))
	{			
		echo "<tr><th><A class='btn btn-sm btn-success' href='view_tour_manage_edit_code.php?place_id=".$row['place_id']."'><i class='fa fa-pencil-square-o' aria-hidden='true'></i></th> <th><A class='btn btn-sm btn-danger' href='view_tour_manage_code.php?place_id=".$row['place_id']."'><i class='fa fa-trash' aria-hidden='true'></i></A></th>";
		 echo "<td>".$row['place_id']."</td>";
		 echo "<td>".$row['place_name']."</td>";
		 echo "<td>".$row['description']."</td>";
		 echo "<td><img src='uploads/".$row['tour_pic']."' width='100px' height='100px'></img></td>";
		 echo "<td>".$row['address']."</td>";
		 echo "<td>".$row['latitute']."</td>";
		 echo "<td>".$row['longitute']."</td>";
		echo "</tr>";
	}
	echo "
	</tbody>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th><th></th>";
	echo "<th>Place Id</th>";
	echo "<th>Place Name</th>";
	echo "<th>Description</th>";
	echo "<th>Tour Pic</th>";
	echo "<th>Address</th>";
	echo "<th>Latitute</th>";
	echo "<th>Longitute</th>";
	echo "</tr>";
	echo "</thead></table>
</div>";
}
else
{

	echo "<h1>Records Not Found</h1>";
}

mysqli_close($conn);
?>
   </div>
   <br>
</div>

<script>
		$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
		
</body>
</html>
