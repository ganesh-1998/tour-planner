<?php 
session_start();
include '../sqlconnections.php';
if(isset($_REQUEST['package_id'])){
	$package_id=$_REQUEST['package_id'];
	$s=explode("-", $package_id);
	$package_id=$s[0];
}
else
	$package_id='null';

if(isset($_REQUEST['place_id'])){
	$place_id=$_REQUEST['place_id'];
	$s=explode("-", $place_id);
	$place_id=$s[0];
}
else
	$place_id='null';




$conn->set_charset("utf8mb4");
$qry="insert into tour_package_places(package_id,place_id) values(?,?)";
$stmt =$conn->prepare($qry);
$stmt->bind_param("ss", $package_id,$place_id); 
$stmt->execute();
if($stmt->affected_rows > 0)
{
	 echo "<script language='javascript'>window.location='add_package.php?msg=Record Added';</script>";
}
else 
{
	echo "<script language='javascript'>window.location='add_package.php?msg=Record Not Added';</script>";
}
mysqli_close($conn);
?>