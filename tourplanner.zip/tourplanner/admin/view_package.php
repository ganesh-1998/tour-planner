<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
   <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'menu.php';
 ?><br>
<div class="container card" style="background-color: #ffffff">
    <h4><b><p style="color:red;">Tour Package Places</p></b></h4>
   
        <?php 
	include 'sqlconnections.php';
?>

<br>
 <?php
$qry="select tour_place_id,package_id,place_id from tour_package_places";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	echo "<table class='table table-sm table-striped' id='table_id'>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th>";
	echo "<th>Tour Place Id</th>";
	echo "<th>Package Id</th>";
	echo "<th>Place Id</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	while($row = mysqli_fetch_assoc($rs))
	{			
		echo "<tr><th><A class='btn btn-sm btn-danger' href='view_package_code.php?tour_place_id=".$row['tour_place_id']."'><i class='fa fa-trash' aria-hidden='true'></i></A></th>";
		 echo "<td>".$row['tour_place_id']."</td>";
		 echo "<td>".$row['package_id']."</td>";
		 echo "<td>".$row['place_id']."</td>";
		echo "</tr>";
		}
	echo "
	</tbody>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th>";
	echo "<th>Tour Place Id</th>";
	echo "<th>Package Id</th>";
	echo "<th>Place Id</th>";
	echo "</tr>";
	echo "</thead></table>
</div>";
}
else
{

	echo "<h4>Records Not Found</h4>";
}

mysqli_close($conn);
?>
   </div>
   <br>
</div>

<script>
		$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
		
</body>
</html>
