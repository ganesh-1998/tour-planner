<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>


<?php 
include 'menu.php';
 ?><br><br><br><br>
<div class="container card" style="background-color: #ffffff;width:40%">
  
  <form name='f1' method='post' action="guide_login_code.php" enctype="">
	
        <div class="row">
			<div class="col-sm-6">
				<img src='images/log.jpg' width='90%' height='90%'>
			</div>
			<div class="col-sm-6">
				<center><h4><u><b><p style="color:red;">Guide Login</p></b></u></h4></center>
				
<div class='row'>
	<div class='col-md-12'>
	<b>	<label for='email'>E-Mail</label></b>
		<input type='email' class='form-control' id='email' placeholder='Enter email' name='email' required >
	</div>
</div>
<div class='row'>
	<div class='col-md-12'>
		<b><label for='password'>Password</label></b>
		<input type='password' class='form-control' id='password' placeholder='Enter password' name='password' required >
	</div>
</div>
				
				<br>
				<button type="submit" class="btn btn-default btn-outline-secondary">Login</button><br>
				<br>
				<label class="checkbox">
                   <b> <a href="guide_new_reg.php" class="text-center new-account text-primary"> New Registration </a></b>
                </label>
	<br>
				<?php
if(isset($_REQUEST['msg']))
{
	 echo '<br><h4>Invalid Username/Password</h4>';
} ?>
<br>
			</div>
		</div>	
		
  
   </form>


		
		
</body>
</html>
