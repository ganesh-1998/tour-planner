<?php 
session_start();
include 'sqlconnections.php';
if(isset($_REQUEST['email']))
	$email=$_REQUEST['email'];
else
	$email='null';

if(isset($_REQUEST['password']))
	$password=$_REQUEST['password'];
else
	$password='null';

$qry="select * from guides where email=? and password=?";
$conn->set_charset("utf8mb4");

$stmt =$conn->prepare($qry);
$stmt->bind_param("ss",$email,$password);
$stmt->execute();
$rs = $stmt->get_result();
if($row = mysqli_fetch_assoc($rs))
{
	$_SESSION['email']=$email;			
	$_SESSION['guide_id']=$row['guide_id']; 
 	echo "<script language='javascript'>alert('Login Successful');window.location='guide/guide_home.php';</script>";
}
else 
{
	 echo "<script language='javascript'>window.location='guide_login.php?msg=Invalid username/password';</script>";
}
mysqli_close($conn);
?>