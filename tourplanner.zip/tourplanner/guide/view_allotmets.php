<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'guide_home_main.php';
 ?><br>
<div class="container card" style="background-color: #ffffff">
    <h4><b><p style="color:green;">Allotments </p></b></h4>   <br> 
        <?php 
		include '../sqlconnections.php';
		function getHotel($conn, $hotel_id){
			$qry="select hotel_name,address,mobile from hotel where hotel_id='$hotel_id'";
			$rs=mysqli_query($conn, $qry);
			if($row=mysqli_fetch_assoc($rs)){
				return $row['hotel_name']."<br>#".$row['address']."<br>".$row['mobile'];
			}
			return 'Nill';
		}

		function getTour($conn, $place_id){
			$qry="select place_name from tour_places where place_id='$place_id'";
			$rs=mysqli_query($conn, $qry);
			if($row=mysqli_fetch_assoc($rs)){
				return $row['place_name'];
			}
			return 'Nill';
		}
?>
      
<?php
$qry="select tour_id,tour_place_id,hotel_id,guide_id from tour_package_guide_hotel where guide_id='".$_SESSION['guide_id']."'";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	echo "<table class='table table-sm table-striped' id='table_id'>";
	echo "<thead class='table-light'>";
	echo "<tr><th>Slno</th>";
	echo "<th>Tour Place Id</th>";
	echo "<th>Hotel</th>";
	echo "<th>Guide Id</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	$i=0;
	while($row = mysqli_fetch_assoc($rs))
	{			
		$i++;
		echo "<tr><th>$i</A></th>";
		 echo "<td>".$row['tour_id']."</td>";
		 echo "<td>".getTour($conn, $row['tour_place_id'])."</td>";
		 echo "<td>". getHotel($conn, $row['hotel_id'])."</td>";
		 
		echo "</tr>";
	}
	echo "
	</tbody>";
	echo "<thead class='table-light'>";
	echo "<tr><th>Slno</th>";
	echo "<th>Tour Place Id</th>";
	echo "<th>Hotel</th>";
	echo "<th>Guide Id</th>";
	echo "</tr>";
	echo "</thead></table>
</div>";
}
else
{

	echo "<h5>Allotment Records are not Found</h5>";
}

mysqli_close($conn);
?>
   </div>
   <br>
</div>

<script>
		$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
		
</body>
</html>
