<!DOCTYPE html>
<html lang="en">
<head>
 <?php
	include 'files/files.php';
  ?>
  </style>
</head>
<body>

<?php 
include 'guide_home_main.php';
 ?>

<div class="jumbotron">
  <div class="container text-center"><br>
    <center><h3><b><p style="color:green;">Welcome to Guide Main Home</p></b></h3></center><br>     
    <p>A tour guide (U.S.) or a tourist guide (European) is a person who provides assistance, information on cultural, historical and contemporary heritage to people on organized sightseeing and individual clients at educational establishments, religious and historical sites such as; museums, and at various venues of tourist ....</p>
    
  </div>
</div>
  
<div class="container-fluid bg-3 text-center card">    
   <div class="row">
    <div class="col-sm-12">
      <img src="images/guide3.jpg" class="img-responsive center" style="width:60%" alt="Image" >
    </div>
   
  </div><br><br><br><br>




</body>
</html>
