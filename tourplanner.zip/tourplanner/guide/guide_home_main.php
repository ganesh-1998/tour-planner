<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
    
      <img src="images\l4.jpg" alt="Logo" style="width:40px;" class="rounded-pill">
      <a class="navbar-brand" href="#" ><span class='text-primary'>Tour Planner</span></a>
    </a>
  </div>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
          	        
	            <li class='nav-item'><a href='guide_home.php' class='nav-link' class='active'>Home</a></li>	        
	            <li class='nav-item'><a href='view_guide_profile.php' class='nav-link' >Profile</a></li>	        
	            <li class='nav-item'><a href='view_allotmets.php' class='nav-link' >Allotments</a></li>	        
	            <li class='nav-item'><a href='../home.php' class='nav-link' >Logout</a></li> 
      </ul>
      
    </div>
  </div>
</nav>
<br><br><br>


  
