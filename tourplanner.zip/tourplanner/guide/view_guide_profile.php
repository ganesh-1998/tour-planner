<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body >

<?php 
include 'guide_home_main.php';
 ?>
<div class="container" style="background-color: #ffffff">
    <h4><b><p style="color:red;">Guide Profile</p></b></h4>   
  
        <?php 
			include '../sqlconnections.php';
		?>

        <br>
   
   
   
   <div class="container card" style='margin-top:-40px'>
        

<?php
$qry="select guide_id,guide_name,address,mobile,email,guide_pic,password from guides where guide_id='".$_SESSION['guide_id']."'";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	echo "<br><table class='table table-bordered display' id='table_id'>";
	echo "<thead class='thead-light'>";
	echo "<tr>";
	echo "<th>guide_id</th>";
	echo "<th>guide_name</th>";
	echo "<th>address</th>";
	echo "<th>mobile</th>";
	echo "<th>email</th>";
	echo "<th>guide_pic</th>";
	echo "<th>password</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	while($row = mysqli_fetch_assoc($rs))
		{
	echo "<tr>";
		 echo "<td>".$row['guide_id']."</td>";
		 echo "<td>".$row['guide_name']."</td>";
		 echo "<td>".$row['address']."</td>";
		 echo "<td>".$row['mobile']."</td>";
		 echo "<td>".$row['email']."</td>";
		 echo "<td><img src='../uploads/".$row['guide_pic']."' width='100px' height='100px'></img></td>";
		 echo "<td>".$row['password']."</td>";
	echo "</tr>";
		}
	echo "
	</tbody>";
	echo "<thead class='thead-light'>";
	echo "<tr>";
	echo "<th>guide_id</th>";
	echo "<th>guide_name</th>";
	echo "<th>address</th>";
	echo "<th>mobile</th>";
	echo "<th>email</th>";
	echo "<th>guide_pic</th>";
	echo "<th>password</th>";
	echo "</tr>";
	echo "</thead></table>
</div>";
}
else
{

	echo "<h1>Records Not Found</h1>";
}
mysqli_close($conn);
?>
   </div>
   <br>
</div>

<script>
		$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
		
</body>
</html>
