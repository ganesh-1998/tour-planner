<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body class='bg' style="background-color:#fc9cac ;background-image: url(images/b1.jpg)">
<?php 
include 'guide_home_main.php';
 ?>
    <div class="container" style="background-color: #ffffff">
        <h4><b><p style="color:green;">Edit Allotment Records </p></b></h4>   <br> 
        <form name='f1' method='post' action="#" enctype="">
    	    <div class="container">
                	<?php 
		
$dbhost = 'localhost';
         
$dbuser = 'root';
         
$dbpass = '';
		 
$dbname = 'tourplannerdb';
         
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
         
if(! $conn )
		 
{
            
	die('Could not connect: ' . mysqli_error());
          
}
			
			
			
$qry="select tour_id,tour_place_id,hotel_id,guide_id from tour_package_guide_hotel where tour_id=		'".$_REQUEST['tour_id']."'";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	$i=1;
	while($row = mysqli_fetch_assoc($rs))
		{
		echo "<div class='row'>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Tour Id</label>";
		echo "<input type='text' class='form-control' name='tour_id' value='".$row['tour_id']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Tour Place Id</label>";
		echo "<input type='text' class='form-control' name='tour_place_id' value='".$row['tour_place_id']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Hotel Id</label>";
		echo "<input type='text' class='form-control' name='hotel_id' value='".$row['hotel_id']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Guide Id</label>";
		echo "<input type='text' class='form-control' name='guide_id' value='".$row['guide_id']."'>";
		echo "</div>";
	echo "</div><hr></hr>";
		}
}
else
{

	echo "<h1>Records Not Found</h1>";
}

?>
            <br>
    	    <button type="submit" name='submit' class="btn btn-default btn-success">Submit</button>
       </form>
       
       <form name='f2' method='post' action='#'>
            			
	<?php
			if(isset($_REQUEST['submit']))
			{
				
			
	$updateqry="update tour_package_guide_hotel set tour_id='".$_REQUEST['tour_id']."' , tour_place_id='".$_REQUEST['tour_place_id']."' , hotel_id='".$_REQUEST['hotel_id']."' , guide_id='".$_REQUEST['guide_id']."'  where tour_id='".$_REQUEST['tour_id']."'";;
			
	if (mysqli_query($conn, $updateqry))
			
	{
			
		echo "<script language='javascript'>window.alert('Record updated successfully');window.location='view_allotmets.php';</script>";
			
	}
			
}mysqli_close($conn);
?>
       </form>
    </div>
</body>
</html>
