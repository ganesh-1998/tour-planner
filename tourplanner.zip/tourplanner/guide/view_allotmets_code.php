	<?php 
		
session_start();
include '../sqlconnections.php';
		 
{
            
	die('Could not connect: ' . mysqli_error());
          
}
			
			
			
$qry="delete from tour_package_guide_hotel where tour_id=		'".$_REQUEST['tour_id']."'";			
	if (mysqli_query($conn, $qry))
			
	{
			
		echo "<script language='javascript'>window.alert('Record deleted successfully');window.location='view_allotmets.php';</script>";
			
	}
			
	mysqli_close($conn);
			
?>