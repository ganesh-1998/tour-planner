<?php
session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
}
?>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'tourist_home_menu.php';
 ?>
 <br>    <div class="container card" style="background-color: #ffffff">
        <h2 class='text-danger'>Edit Profile</h2>
<form name='f1' method='post' action="#" enctype="">

<?php 
include 'sqlconnections.php';			
			
			
$qry="select customer_id,customer_name,address,zipcode,mobile,email,pic,password,registerDate from customers where customer_id='".$_REQUEST['customer_id']."'";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	$i=1;
	while($row = mysqli_fetch_assoc($rs))
		{
		echo "<div class='row'>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Customer Id</label>";
		echo "<input type='text' class='form-control' name='customer_id' value='".$row['customer_id']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Customer Name</label>";
		echo "<input type='text' class='form-control' name='customer_name' value='".$row['customer_name']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Address</label>";
		echo "<input type='text' class='form-control' name='address' value='".$row['address']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Zipcode</label>";
		echo "<input type='text' class='form-control' name='zipcode' value='".$row['zipcode']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Mobile</label>";
		echo "<input type='text' class='form-control' name='mobile' value='".$row['mobile']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Email</label>";
		echo "<input type='text' class='form-control' name='email' value='".$row['email']."'>";
		echo "</div>";
		
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Password</label>";
		echo "<input type='text' class='form-control' name='password' value='".$row['password']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>RegisterDate</label>";
		echo "<input type='text' class='form-control' name='registerDate' value='".$row['registerDate']."'>";
		echo "</div>";
	echo "</div><hr></hr>";
		}
}
else
{

	echo "<h1>Records Not Found</h1>";
}

?>
            <br>
    	    <button type="submit" name='submit' class="btn btn-default btn-success">Update</button>
       </form>
       
       <form name='f2' method='post' action='#'>
            			
	<?php
	if(isset($_REQUEST['submit']))
	{
		$updateqry="update customers set  customer_name='".$_REQUEST['customer_name']."' , address='".$_REQUEST['address']."' , zipcode='".$_REQUEST['zipcode']."' , mobile='".$_REQUEST['mobile']."' , email='".$_REQUEST['email']."', password='".$_REQUEST['password']."' , registerDate='".$_REQUEST['registerDate']."'  where customer_id='".$_REQUEST['customer_id']."'";;
		if (mysqli_query($conn, $updateqry))
		{
			echo "<script language='javascript'>window.alert('Record updated successfully');window.location='tourist_profile.php';</script>";
		}
	}
	mysqli_close($conn);
?>
       </form>
    </div>
</body>
</html>
