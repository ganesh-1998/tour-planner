<?php
session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
}
?>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'tourist_home_menu.php';
include '../sqlconnections.php';
?>
<div>

<h5 class='pull-right'>Hi! <b class='text-success'><?php echo $_SESSION['customer_name'];?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b> </h5>
</div>

 <br>
 <div class="container card" style="background-color: #ffffff">

<?php

$qry="select package_id,package_name,package_description,package_pic,price,start_date,end_date from tour_package  order by start_date desc";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	echo "<br><table class='table table-sm table-striped' id='table_id'>";
	echo "<thead class='table-light'>";
	echo "<tr>";
	echo "<th>Slno</th>";
    echo "<th>Package Pic</th>";
	echo "<th>Package Name</th>";
	echo "<th>Package Description</th>";
	
	echo "<th>Price</th>";
	echo "<th>Start Date</th>";
	echo "<th>End Date</th>";
    echo "<th></th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
    $i=0;
	while($row = mysqli_fetch_assoc($rs))
	{
         $i++;
	     echo "<tr>";
		 echo "<td>".$i."</td>";
         echo "<td><img src='../admin/uploads/".$row['package_pic']."' width='100px' height='100px'></img></td>";
		 echo "<td>".$row['package_name']."</td>";
		 echo "<td>".$row['package_description']."</td>";

        $qry1 ="";

		
		 echo "<td>".$row['price']."</td>";
		 echo "<td>".$row['start_date']."</td>";
		 echo "<td>".$row['end_date']."</td>";
         echo "<td><A class='btn btn-outline-primary' href='tour_package_details.php?package_id=".$row['package_id']."&price=".$row['price']."'>Book Tour</A></td>";
	     echo "</tr>";
	}
	echo "</tbody>";
	echo "<thead class='table-light'>";
	echo "<tr>";
	echo "<th>Slno</th>";
    echo "<th>Package Pic</th>";
	echo "<th>Package Name</th>";
	echo "<th>Package Description</th>";
	
	echo "<th>Price</th>";
	echo "<th>Start Date</th>";
	echo "<th>End Date</th>";
    echo "<th></th>";
	echo "</tr>";
	echo "</thead></table></div>";
}
else
{

	echo "<h3>Records Not Found</h3>";
}
mysqli_close($conn);
?>
	</div>
	</div>



    <script>
		$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>

</body>
</html>
