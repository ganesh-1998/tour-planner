<?php
session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
}
?>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'tourist_home_menu.php';
?>
<div>

<h5 class='pull-right'>Hi! <b class='text-success'><?php echo $_SESSION['customer_name'];?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b> </h5>
</div>

<div class="jumbotron">
  <div class="container text-center"><br>
    <h4><b><p style="color:red;">Welcome to Tourist Home</p></b></h4>      
    <p>Tourism is travel for pleasure or business, and the commercial activity of providing and supporting such travel.</p>
    
  </div>
</div>
  
<div class="container-fluid bg-3 text-center">    
   <div class="row">
    <div class="col-sm-12">
      <img src="images/ta.jpg" class="img-responsive center" style="width:70%" alt="Image" >
    </div>
   
  </div>
</div>

</body>
</html>
