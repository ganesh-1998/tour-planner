<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="images\l4.jpg" alt="Logo" style="width:40px;" class="rounded-pill">
      <a class="navbar-brand" href="#" ><span class='text-primary'>Tour Planner</span></a>
    </a>
  </div>

    <div class="collapse navbar-collapse" id="collapsibleNavbar">

      <ul class="navbar-nav">
	            <li class='nav-item'><a href='tourist_home.php' class='nav-link' class='active'>Home</a></li>	        
	            <li class='nav-item'><a href='tourist_profile.php' class='nav-link' >Profile</a></li>	 
              <li class='nav-item'><a href='tours.php' class='nav-link' class='active'>Tours</a></li>	  
              <li class='nav-item'><a href='view_history.php' class='nav-link' >History</a></li>	       
	            <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" href="#">Feedback<span class="caret"></span></a>
          <ul class="dropdown-menu">	        
	            <li class='nav-item'><a href='give_feedback.php' class="dropdown-item" >Give</a></li>	        
	            <li class='nav-item'><a href='view_feedback.php' class="dropdown-item" >View</a></li>                
          </ul>
            </li>	        
	            <li class='nav-item'><a href='logout.php' class='nav-link' >Logout</a></li> 
      </ul>
      
    </div>
  </div>
</nav>
<br><br><br>
