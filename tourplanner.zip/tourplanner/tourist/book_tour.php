<?php
session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
}
?>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'tourist_home_menu.php';
include '../sqlconnections.php';
?>
<div>

<h5 class='pull-right'>Hi! <b class='text-success'><?php echo $_SESSION['customer_name'];?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b> </h5>
</div>

 <br>
 <div class="container card" style="background-color: #ffffff">
    <h2 class='text-danger'>Book Tour</h2>
    <?php 
include '../sqlconnections.php';
$package_id=$_SESSION['package_id'];

?>
<br><br>
<div class='row'>
<div class='col-sm-5'>
		<form name='f1' method='post' action='book_tour_code.php'>
            
			<div class='row'>
				<div class='col-sm-12'>
					Card Type<br>
					<select name='card_type' class='form-control'>
						<option>Debit Card</option>
						<option>Credit Card</option>
					</select>
				</div>
			</div>
			<div class='row'>
				<div class='col-sm-12'>
					Card Number<br>
					<input type='number' name='card_no' class='form-control'  value='0' required>
				</div>
			</div>

            <div class='row'>
				<div class='col-sm-12'>
					Expiry Date<br>
					<input type='text' name='exp_date' class='form-control'  value='' required>
				</div>
			</div>

            <div class='row'>
				<div class='col-sm-12'>
					CVV<br>
					<input type='number' name='cvv' class='form-control'  value='0' required>
				</div>
			</div>
			
			<div class='row'>
				<div class='col-sm-12'>
					<br><input type='submit' name='submit' value='Place Order' class='form-control btn btn-outline-dark'>
				</div>
			</div>
		
		</form>
		
		
		</div>


   </div>
   <br>
<?php
    if( isset($_REQUEST['msg'])){
        echo "<h4 class='text-danger'>".$_REQUEST['msg']."</h4>";
    }

?>



</div>


</body>
</html>
