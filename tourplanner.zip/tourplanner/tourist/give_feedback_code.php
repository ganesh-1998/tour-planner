<?php 
session_start();
include '../sqlconnections.php';

$customer_id=$_SESSION['customer_id'];


if(isset($_REQUEST['package_id']))
	$package_id=$_REQUEST['package_id'];
else
	$package_id='null';

if(isset($_REQUEST['feedback']))
	$feedback=$_REQUEST['feedback'];
else
	$feedback='null';

if(isset($_REQUEST['rating']))
	$rating=$_REQUEST['rating'];
else
	$rating='null';

$qry="insert into feedback(feedback_date,customer_id,package_id,feedback,rating) values(curdate(),'$customer_id','$package_id','$feedback','$rating')";

if(mysqli_query($conn, $qry))
 {
	 echo "<script language='javascript'>alert('Record Added Successfully.');window.location='give_feedback.php';</script>";}
 else 
 {
	 echo 'Error: '.mysqli_error($conn);
}
mysqli_close($conn);
?>