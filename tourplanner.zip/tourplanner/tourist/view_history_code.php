	<?php 
session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
}
include '../sqlconnections.php';
$qry="delete from payments where payment_id=		'".$_REQUEST['payment_id']."'";			
	if (mysqli_query($conn, $qry))
{
	echo "<script language='javascript'>window.alert('Record deleted successfully');window.location='view_history.php';</script>";
			
	}
	mysqli_close($conn);
			
?>