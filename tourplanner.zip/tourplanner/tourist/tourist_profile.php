<?php
session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
}
?>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'tourist_home_menu.php';
 ?>
 <br>
<div class="container card" style="background-color: #ffffff">
    <h2 class='text-danger'>Tourist Profile</h2>
   
    <?php 
		include '../sqlconnections.php';?>

        <br>
   

<?php
$qry="select customer_id,customer_name,address,zipcode,mobile,email,pic,password,registerDate from customers where customer_id='".$_SESSION['customer_id']."'";


$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	echo "<table class='table table-sm table-striped' id='table_id'>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th>";
	echo "<th>Customer Id</th>";
	echo "<th>Customer Name</th>";
	echo "<th>Address</th>";
	echo "<th>Zipcode</th>";
	echo "<th>Mobile</th>";
	echo "<th>Email</th>";
	echo "<th>Pic</th>";
	echo "<th>Password</th>";
	echo "<th>RegisterDate</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	while($row = mysqli_fetch_assoc($rs))
		{			
	
			
	echo "<tr><th><A class='btn btn-sm btn-success' href='tourist_profile_edit_code.php?customer_id=".$row['customer_id']."'><i class='fa fa-pencil-square-o' aria-hidden='true'></i></th> ";
		 echo "<td>".$row['customer_id']."</td>";
		 echo "<td>".$row['customer_name']."</td>";
		 echo "<td>".$row['address']."</td>";
		 echo "<td>".$row['zipcode']."</td>";
		 echo "<td>".$row['mobile']."</td>";
		 echo "<td>".$row['email']."</td>";
		 echo "<td><img src='uploads/".$row['pic']."' width='100px' height='100px'></img></td>";
		 echo "<td>".$row['password']."</td>";
		 echo "<td>".$row['registerDate']."</td>";
	echo "</tr>";
		}
	echo "
	</tbody>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th>";
	echo "<th>Customer Id</th>";
	echo "<th>Customer Name</th>";
	echo "<th>Address</th>";
	echo "<th>Zipcode</th>";
	echo "<th>Mobile</th>";
	echo "<th>Email</th>";
	echo "<th>Pic</th>";
	echo "<th>Password</th>";
	echo "<th>RegisterDate</th>";
	echo "</tr>";
	echo "</thead></table>
</div>";
}
else
{

	echo "<h1>Records Not Found</h1>";
}

mysqli_close($conn);
?>
   </div>
   <br>
</div>

<script>
		$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
		
</body>
</html>
