<?php session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body style="background-color: #ffffff;background-image: url(images/)">

<?php 
include 'tourist_home_menu.php';
 ?>
    <div class="container" style="background-color: #ffffff">
        <h2>Edit Record</h2>
        <form name='f1' method='post' action="#" enctype="">
    	    <div class="container">
                	<?php 
		
$dbhost = 'localhost';
         
$dbuser = 'root';
         
$dbpass = '';
		 
$dbname = 'tourplannerdb';
         
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
         
if(! $conn )
		 
{
            
	die('Could not connect: ' . mysqli_error());
          
}
			
			
			
$qry="select payment_id,payment_date,package_id,customer_id,payment_type,card_type,card_no,exp_date,cvv,price from payments where payment_id=		'".$_REQUEST['payment_id']."'";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	$i=1;
	while($row = mysqli_fetch_assoc($rs))
		{
		echo "<div class='row'>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Payment Id</label>";
		echo "<input type='text' class='form-control' name='payment_id' value='".$row['payment_id']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Payment Date</label>";
		echo "<input type='text' class='form-control' name='payment_date' value='".$row['payment_date']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Package Id</label>";
		echo "<input type='text' class='form-control' name='package_id' value='".$row['package_id']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Customer Id</label>";
		echo "<input type='text' class='form-control' name='customer_id' value='".$row['customer_id']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Payment Type</label>";
		echo "<input type='text' class='form-control' name='payment_type' value='".$row['payment_type']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Card Type</label>";
		echo "<input type='text' class='form-control' name='card_type' value='".$row['card_type']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Card No</label>";
		echo "<input type='text' class='form-control' name='card_no' value='".$row['card_no']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Exp Date</label>";
		echo "<input type='text' class='form-control' name='exp_date' value='".$row['exp_date']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Cvv</label>";
		echo "<input type='text' class='form-control' name='cvv' value='".$row['cvv']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Price</label>";
		echo "<input type='text' class='form-control' name='price' value='".$row['price']."'>";
		echo "</div>";
	echo "</div><hr></hr>";
		}
}
else
{

	echo "<h1>Records Not Found</h1>";
}

?>
            <br>
    	    <button type="submit" name='submit' class="btn btn-default btn-success">Submit</button>
       </form>
       
       <form name='f2' method='post' action='#'>
            			
	<?php
			if(isset($_REQUEST['submit']))
			{
				
			
	$updateqry="update payments set payment_id='".$_REQUEST['payment_id']."' , payment_date='".$_REQUEST['payment_date']."' , package_id='".$_REQUEST['package_id']."' , customer_id='".$_REQUEST['customer_id']."' , payment_type='".$_REQUEST['payment_type']."' , card_type='".$_REQUEST['card_type']."' , card_no='".$_REQUEST['card_no']."' , exp_date='".$_REQUEST['exp_date']."' , cvv='".$_REQUEST['cvv']."' , price='".$_REQUEST['price']."'  where payment_id='".$_REQUEST['payment_id']."'";;
			
	if (mysqli_query($conn, $updateqry))
			
	{
			
		echo "<script language='javascript'>window.alert('Record updated successfully');window.location='view_history.php';</script>";
			
	}
			
}mysqli_close($conn);
?>
       </form>
    </div>
</body>
</html>
