<?php
session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
}
include '../sqlconnections.php';

$package_id= $_SESSION['package_id'];
$price= $_SESSION['price'];
$customer_id=$_SESSION['customer_id'];
$payment_type='online';
$conn->set_charset("utf8mb4");

$today=date('Y-m-d');
$stmt = $conn->prepare("insert into payments(payment_date,package_id,customer_id,payment_type,card_type,card_no,price) values(?,?,?,?,?,?,?)");
$stmt->bind_param("sssssss", $today,$package_id,$customer_id,$payment_type,$_SESSION['card_type'],$_SESSION['card_no'],$price);

if($stmt->execute())
 {

    $stmt = $conn->prepare("update accounts set balance=balance+? where card_no='100000000001'");
    $stmt->bind_param("s", $price);
    $stmt->execute();

    $stmt = $conn->prepare("update accounts set balance=balance-? where card_no='".$_SESSION['card_no']."'");
    $stmt->bind_param("s", $price);
    $stmt->execute();

    
	 echo "<script language='javascript'>window.alert('Tour successfully booked.');window.location='tourist_home.php';</script>";
 }
 else 
 {
       echo "<script language='javascript'>window.alert('Tour booking failed. Try again!!!');window.location='tourist_home.php';</script>";
}

$stmt->close();
$conn->close();

?>
