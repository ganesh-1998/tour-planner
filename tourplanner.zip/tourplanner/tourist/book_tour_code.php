<?php 
session_start();

include '../sqlconnections.php';
if(isset($_REQUEST['card_type']))
	$card_type=$_REQUEST['card_type'];
else
	$card_type='null';

if(isset($_REQUEST['card_no']))
	$card_no=$_REQUEST['card_no'];
else
	$card_no='null';

if(isset($_REQUEST['exp_date']))
	$exp_date=$_REQUEST['exp_date'];
else
	$exp_date='null';

if(isset($_REQUEST['cvv']))
	$cvv=$_REQUEST['cvv'];
else
	$cvv='null';

$package_id= $_SESSION['package_id'];
$price= $_SESSION['price'];

$otp = rand(10000,99999);
$_SESSION['otp']=$otp;
//$qry="select * from accounts where card_type='$card_type' and card_no='$card_no' and exp_date='$exp_date' and cvv='$cvv' and balance>'$price'";

$qry="select * from accounts where card_type=? and card_no=? and exp_date=? and cvv=? and balance>?";
$conn->set_charset("utf8mb4");

$stmt =$conn->prepare($qry);
$stmt->bind_param("sssss",$card_type,$card_no,$exp_date,$cvv,$price);
$stmt->execute();
$rs = $stmt->get_result();


//if (mysqli_num_rows($rs) > 0) {
if($row = mysqli_fetch_assoc($rs))
 {
    $_SESSION['card_type'] =$card_type;
    $_SESSION['card_no'] =$card_no;
    $_SESSION['exp_date'] =$exp_date;
    $_SESSION['cvv'] =$cvv;

	 echo "<script language='javascript'>window.location='book_tour_OTP.php';</script>";
	 
	 
	
}
 else 
 {
	 echo "<script language='javascript'>window.location='book_tour.php?msg=Invalid card details/insufficient funds.';</script>";
}
mysqli_close($conn);
?>