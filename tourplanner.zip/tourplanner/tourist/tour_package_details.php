<?php
session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
}
?>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'tourist_home_menu.php';
include '../sqlconnections.php';
?>
<div>

<h5 class='pull-right'>Hi! <b class='text-success'><?php echo $_SESSION['customer_name'];?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b> </h5>
</div>

 <br>
 <div class="container card" style="background-color: #ffffff">
    <h2 class='text-danger'>Tour Package Details</h2>
    <?php 

include '../sqlconnections.php';
$package_id=$_REQUEST['package_id'];
$price=$_REQUEST['price'];
$_SESSION['package_id'] = $package_id;
$_SESSION['price'] = $price;

$qry="select place_id,place_name,description,tour_pic,address from tour_places where place_id in (select place_id from tour_package_places where package_id='$package_id')";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	echo "<br><table class='table table-sm table-striped'>";
	echo "<thead class='table-light'>";
	echo "<tr>";
	echo "<th>Place Id</th>";
	echo "<th>Place Name</th>";
	echo "<th>Description</th>";
	echo "<th>Tour Pic</th>";
	echo "<th>Address</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	while($row = mysqli_fetch_assoc($rs))
	{
	    echo "<tr>";
		 echo "<td>".$row['place_id']."</td>";
		 echo "<td>".$row['place_name']."</td>";
		 echo "<td>".$row['description']."</td>";
		 echo "<td><img src='../admin/uploads/".$row['tour_pic']."' width='100px' height='100px'></img></td>";
		 echo "<td>".$row['address']."</td>";
	    echo "</tr>";
	}
	echo "</tbody>";
	echo "</table>";
}
else
{

	echo "<h3>Records Not Found</h3>";
}
mysqli_close($conn);
?>
<br><br>
<div class='row'>
    <div class='col-sm-3'>
        <A class='btn btn-outline-dark' href='book_tour.php'>Book Tour</A>
    </div>  

</div>
<br>


   </div>
   <br>
</div>

<script>
		$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
		
</body>
</html>
