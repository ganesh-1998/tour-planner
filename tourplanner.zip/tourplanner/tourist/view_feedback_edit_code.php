<?php session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body style="background-color: #ffffff;background-image: url(images/)">

<?php 
include 'tourist_home_menu.php';
 ?>
    <div class="container" style="background-color: #ffffff">
        <h2>Edit Record</h2>
        <form name='f1' method='post' action="#" enctype="">
    	    <div class="container">
<?php 
		include '../sqlconnections.php';
			
$qry="select feedback_id,feedback_date,customer_id,package_id,feedback,rating from feedback where feedback_id=		'".$_REQUEST['feedback_id']."'";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	$i=1;
	while($row = mysqli_fetch_assoc($rs))
		{
		echo "<div class='row'>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Feedback Id</label>";
		echo "<input type='text' class='form-control' name='feedback_id' value='".$row['feedback_id']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Feedback Date</label>";
		echo "<input type='text' class='form-control' name='feedback_date' value='".$row['feedback_date']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Customer Id</label>";
		echo "<input type='text' class='form-control' name='customer_id' value='".$row['customer_id']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Package Id</label>";
		echo "<input type='text' class='form-control' name='package_id' value='".$row['package_id']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Feedback</label>";
		echo "<input type='text' class='form-control' name='feedback' value='".$row['feedback']."'>";
		echo "</div>";
		echo "<div class='col-sm-3'>";
		echo "<label class='form-check-label'>Rating</label>";
		echo "<input type='text' class='form-control' name='rating' value='".$row['rating']."'>";
		echo "</div>";
	echo "</div><hr></hr>";
		}
}
else
{

	echo "<h1>Records Not Found</h1>";
}

?>
            <br>
    	    <button type="submit" name='submit' class="btn btn-default btn-success">Submit</button>
       </form>
       
       <form name='f2' method='post' action='#'>
            			
	<?php
			if(isset($_REQUEST['submit']))
			{
				
			
	$updateqry="update feedback set feedback_id='".$_REQUEST['feedback_id']."' , feedback_date='".$_REQUEST['feedback_date']."' , customer_id='".$_REQUEST['customer_id']."' , package_id='".$_REQUEST['package_id']."' , feedback='".$_REQUEST['feedback']."' , rating='".$_REQUEST['rating']."'  where feedback_id='".$_REQUEST['feedback_id']."'";;
			
	if (mysqli_query($conn, $updateqry))
			
	{
			
		echo "<script language='javascript'>window.alert('Record updated successfully');window.location='view_feedback.php';</script>";
			
	}
			
}mysqli_close($conn);
?>
       </form>
    </div>
</body>
</html>
