<?php session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
} ?>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>
<?php 
	include 'tourist_home_menu.php';
	include '../sqlconnections.php';

	function getPackage($conn, $package_id){
		$qry="select package_id,package_name,package_description,package_pic,price,start_date,end_date from tour_package  where package_id='$package_id'";
	$rs=mysqli_query($conn, $qry);
	if($row = mysqli_fetch_assoc($rs))
	{
		return $row['package_name']."<br>".$row['package_description']."<br>Price:".$row['price']."<br>From:".$row['start_date']." to ".$row['end_date'];
	}
	return "nill";
}	
 ?>
<div class="container card" style="background-color: #ffffff">
    <h3><b><p style="color:red;">History</p></b></h3> 
         

<?php
$qry="select payment_id,payment_date,package_id,customer_id,payment_type,card_type,card_no,price from payments where customer_id='".$_SESSION['customer_id']."' order by  payment_date desc";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	echo "<table class='table table-sm table-striped' id='table_id'>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th>";

	echo "<th>Payment Date</th>";
	echo "<th>Package</th>";
	
	echo "<th>Payment Type</th>";
	echo "<th>Card Type</th>";
	echo "<th>Card No</th>";
	echo "<th>Price</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	$i=0;
	while($row = mysqli_fetch_assoc($rs))
	{	
		$i++;
		echo "<tr><th>$i</th>";
	
		 echo "<td>".$row['payment_date']."</td>";
		 echo "<td>".getPackage($conn, $row['package_id'])."</td>";
		
		 echo "<td>".$row['payment_type']."</td>";
		 echo "<td>".$row['card_type']."</td>";
		 echo "<td>".$row['card_no']."</td>";
		 echo "<td>".$row['price']."</td>";
		echo "</tr>";
	}
	echo "
	</tbody>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th>";

	echo "<th>Payment Date</th>";
	echo "<th>Package Id</th>";
	
	echo "<th>Payment Type</th>";
	echo "<th>Card Type</th>";
	echo "<th>Card No</th>";
	echo "<th>Price</th>";
	echo "</tr>";
	echo "</thead></table>
</div>";
}
else
{

	echo "<h4>Records Not Found</h4>";
}

mysqli_close($conn);
?>
   </div>
   <br>
</div>

<script>
		$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
		
</body>
</html>
