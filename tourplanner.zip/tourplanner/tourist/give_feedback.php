<?php session_start(); 
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
}?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>
<?php 
include 'tourist_home_menu.php';
include '../sqlconnections.php';
 ?>
 <br>
  <div class="container card" style="background-color: #ffffff;width:60%">
      <center><h4><b><p style="color:red;">Give Feedback</p></b></h4> </center>
  <form name='f1' method='post' action="give_feedback_code.php" enctype="multipart/form-data">
	
	<div class="row">
		<div class="col-sm-6">
			<img src="images/fb2.png" width="90%" alt="add image path">
		</div>
		
		<div class="col-sm-6">
		 
<div class='row'>
	<div class='col-md-12'>
		<label for='package_id'>Package Id</label>
		<select name='package_id' style='width:400px;height:30px'>
		<?php
			$qry="select package_id from tour_package order by package_id";
			$rs=mysqli_query($conn, $qry);
			while($row = mysqli_fetch_assoc($rs))
			{
				echo "<option>".$row['package_id']."</option>";
			}
		?>
	</select>
	</div>
	<div class='col-md-12'>
		<label for='feedback'>Feedback</label>
		<textarea rows='3' class='form-control' id='feedback' placeholder='Feedback' name='feedback' required ></textarea>
	</div>

	<div class='col-md-12'>
		<label for='rating'>Rating</label>
		<select class='form-control' id='rating' name='rating' required >
		<option>--Select--</option>
		<option>1</option>
		<option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
		</select>
	</div>
</div>

		<br>
		<button type="submit" class="btn btn-default btn-success">Add Feedback</button><br><br>
		</div>
		<br>
	
	</div>
        
       
   
   </form>
</div>
		
		
</body>
</html>
