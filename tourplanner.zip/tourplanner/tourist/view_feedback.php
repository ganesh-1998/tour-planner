<?php session_start();
if(!isset($_SESSION['email'])){
	echo "<script language='javascript'>window.location='../tourist_login.php';</script>";
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'tourist_home_menu.php';
 ?><br>
<div class="container" style="background-color: #ffffff">
    <h4><b><p style="color:green;">View Feedback</p></b></h4> 
 
   
   <div class="container" style='margin-top:-40px'>
        <?php 
	include '../sqlconnections.php';
?>

<?php
$qry="select feedback_id,feedback_date,customer_id,package_id,feedback,rating from feedback where customer_id='".$_SESSION['customer_id']."'";
$rs=mysqli_query($conn, $qry);
if (mysqli_num_rows($rs) > 0) 
{
	echo "<br><br><table class='table table-sm table-striped' id='table_id'>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th><th></th>";
	echo "<th>Feedback Id</th>";
	echo "<th>Feedback Date</th>";
	echo "<th>Customer Id</th>";
	echo "<th>Package Id</th>";
	echo "<th>Feedback</th>";
	echo "<th>Rating</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	while($row = mysqli_fetch_assoc($rs))
		{			
	
			
	echo "<tr><th><A class='btn btn-sm btn-success' href='view_feedback_edit_code.php?feedback_id=".$row['feedback_id']."'>Edit</th> <th><A class='btn btn-sm btn-danger' href='view_feedback_code.php?feedback_id=".$row['feedback_id']."'>Delete</A></th>";
		 echo "<td>".$row['feedback_id']."</td>";
		 echo "<td>".$row['feedback_date']."</td>";
		 echo "<td>".$row['customer_id']."</td>";
		 echo "<td>".$row['package_id']."</td>";
		 echo "<td>".$row['feedback']."</td>";
		 echo "<td>".$row['rating']."</td>";
	echo "</tr>";
		}
	echo "
	</tbody>";
	echo "<thead class='table-light'>";
	echo "<tr><th></th><th></th>";
	echo "<th>Feedback Id</th>";
	echo "<th>Feedback Date</th>";
	echo "<th>Customer Id</th>";
	echo "<th>Package Id</th>";
	echo "<th>Feedback</th>";
	echo "<th>Rating</th>";
	echo "</tr>";
	echo "</thead></table>
</div>";
}
else
{

	echo "<br><br><h4>Records Not Found</h4>";
}

mysqli_close($conn);
?>
   </div>
   <br>
</div>

<script>
		$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
		
</body>
</html>
