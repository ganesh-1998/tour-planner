<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script language='javascript'>
	function verifyPasswords() {
	var pwd = document.getElementById("pwd").value;
	var cpwd= document.getElementById("cpwd").value;
	var div1=document.getElementById("div1");
	if (pwd != cpwd) {
 		document.getElementById("cpwd").value="";
		
		div1.innerHTML ='Passwords not matched';
		div1.style.color='red';
		return false;
	 }
	 div1.innerHTML ='Passwords matched';
	 div1.style.color='green';
		return true;
    }
	</script>

</head>
<body>

<?php 
include 'menu.php';
 ?>
 <br><br><br>
<div class="container card" style="background-color: #ffffff;margin-top:20px;width:60%" >
  <center><h4><u><b><p style="color:red;">Tourist Registration Form</p></b></u></h4></center>
  <form name='f1' method='post' action="tourist_new_reg_code.php" enctype="multipart/form-data">
	
        
        
<div class='row'>
	<div class='col-md-6'>
		<b><label for='customer_name'>Customer Name</label></b>
		<input type='text' class='form-control' id='customer_name' placeholder='Customer Name' name='customer_name' required >
	</div>
	<div class='col-md-6'>
	<b>	<label for='address'>Address</label></b>
		<textarea rows='3' class='form-control' id='address' placeholder='Address' name='address' required ></textarea>
	</div>
</div>
<div class='row'>
	<div class='col-md-6'>
		<b><label for='zipcode'>Zip Code</label></b>
		<input type='text' class='form-control' id='zipcode' placeholder='Zipcode' name='zipcode' required >
	</div>
	<div class='col-md-6'>
	<b>	<label for='mobile'>Mobile Number</label></b>
		<input type='text' class='form-control' id='mobile' placeholder='Mobile' name='mobile'pattern="[0-9]{10}" title="Please enter correct mobile number" required >
	</div>
</div>
<div class='row'>
	<div class='col-md-6'>
		<b><label for='email'>E-Mail</label></b>
		<input type='email' class='form-control' id='email' placeholder='Email' name='email' pattern="[^@\s]+@[^@\s]+\.[^@\s]+" title="Please enter correct email" required >
	</div>
	<div class='col-md-6'>
		<b><label for='pic'>Photo</label></b>
		<input type='file' class='form-control' id='pic' placeholder='Pic' name='pic' >
	</div>
</div>
<div class='row'>
	<div class='col-md-6'>
	<b>	<label for='password'>Password</label></b>
		<input type='password' class='form-control' id='pwd' placeholder='Password' name='password' pattern="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=\S+$)(?=.*[!@#$%^&*_=+-]).{8,}$" title="Invalid password" required >
		
	</div>
	<div class='col-md-6'>
		<b><label for='cpassword'>Confirm-Password</label></b>
		<input type='password' class='form-control' id='cpwd' placeholder='Confirm-Password' name='cpassword' onfocusout='verifyPasswords()' required >
		<br>
		<div id='div1'></div>
		</div>
		<br>

		<div class='text-danger'>
			Password must satisfy the following.
		<p>1. Minimum password length is 8.
			<br> 2. Atleast one capital letter.
			<br>3.  Atleast one small letter.
				<br>4. Atleast one special symbol.

		<div>
		

	<div class="g-recaptcha" data-sitekey="6LeIURklAAAAAAthGgx3Y0535oU4f1qGys_GneW3" data-callback="verify_recaptcha"></div> 

		
</div>
   <br>
<center>	<button type="submit" class="btn btn-default btn-outline-secondary" name="register_btn" value=" register " id='register' disabled>Register</button> </center>
	<?php
		if(isset($_REQUEST['msg'])){
			echo "<h4 class='text-success'>".$_REQUEST['msg']."</h4>";
		}
	?>
	<br><br>
   </form>
</div>
<script type="text/javascript">
      function verify_recaptcha() {
        const submitButton = document.getElementById("register");
        submitButton.removeAttribute("disabled");
      }
    </script>
	
	
	

</body>
</html>
