<?php
session_start();
include 'sqlconnections.php';



if(isset($_SESSION['ans']) && $_REQUEST['ans'] == $_SESSION['ans']){

}
else{
	echo "<script language='javascript'>window.location='tourist_login.php?msg=Wrong ans!!';</script>";
}

if(isset($_REQUEST['email']))
	$email=$_REQUEST['email'];
else
	$email='null';

if(isset($_REQUEST['password']))
	$password=$_REQUEST['password'];
else
	$password='null';

$conn->set_charset("utf8mb4");

$stmt = $conn->prepare("select * from customers where email=? and password=?");
$stmt->bind_param("ss", $email,$password);
$stmt->execute();
$result = $stmt->get_result();

if($row = $result->fetch_assoc()) 
{
	$_SESSION['customer_name']=$row['customer_name'];
	$_SESSION['customer_id']=$row['customer_id'];			
	$_SESSION['email']=$email;	
	$_SESSION['mobile']=$row['mobile'];			
	echo "<script language='javascript'>alert('Login Successful');window.location='tourist/tourist_home.php';</script>";
 }
 else 
 {
	 echo "<script language='javascript'>window.location='tourist_login.php?msg=Invalid username/password';</script>";
 }
$stmt->close();
$conn->close();
?>