<html>
<head>
<?php
	include 'files/files.php';
  ?>

<style>
.paddingTB60 {padding:60px 0px 60px 0px;}
.gray-bg {background: #F1F1F1 !important;}
.about-title {}
.about-title h1 {color: #535353; font-size:45px;font-weight:600;}
.about-title span {color: #AF0808; font-size:45px;font-weight:700;}
.about-title h3 {color: #535353; font-size:23px;margin-bottom:24px;}
.about-title p {color: #7a7a7a;line-height: 1.8;margin: 0 0 15px;}
.about-paddingB {padding-bottom: 12px;}
</style>
</head>
<body class='bg' style="background-color:#fc9cac ;background-image: url(images/11.jpg)">

<?php 
include 'menu.php';
 ?>
<div class="about-section paddingTB60 gray-bg">
                <div class="container">
                    <div class="row">
						<div class="col-md-6 col-sm-6">
							<div class="about-title clearfix">
								<h4><b><p style="color:purple;">About Tour Planner</p></b></h4> 
								<p class="about-paddingB">A journey planner, trip planner, or route planner is a specialized search engine used to find an optimal means of travelling between two or more given locations, sometimes using more than one transport mode.[1][2] Searches may be optimized on different criteria, for example fastest, shortest, fewest changes, cheapest.[3] They may be constrained, for example, to leave or arrive at a certain time, to avoid certain waypoints, etc. A single journey may use a sequence of several modes of transport, meaning the system may know about public transport services as well as transport networks for private transportation. Trip planning or journey planning is sometimes distinguished from route planning,[4] which is typically thought of as using private modes of transportation such as cycling, driving, or walking, normally using a single mode at a time. Trip or journey planning, in contrast, would make use of at least one public transport mode which operates according to published schedules; given that public transport services only depart at specific times (unlike private transport which may leave at any time), an algorithm must therefore not only find a path to a destination, but seek to optimize it so as to minimize the waiting time incurred for each leg.</p>
					
							</div>
						</div>
						
						<div class="col-md-6"><br><br>
							<img src="images/about2.jpg"><br><br>
							<img src="images/about3.jpg"><br><br>
							<img src="images/tt.jpg">
							
						</div>
                    </div>
                </div>
            </div>
			</body>
			</html>