<?php
$recaptcha = new Quform_Element('g-recaptcha-response', 'reCAPTCHA');
$recaptcha->addValidator('required');
$recaptcha->addValidator('recaptcha', array('secretKey' => '6LeIURklAAAAAINS8JIGxSmspCoY5Cauw0zWqzku'));
$recaptcha->setIsHidden(true);
$form->addElement($recaptcha);
?>