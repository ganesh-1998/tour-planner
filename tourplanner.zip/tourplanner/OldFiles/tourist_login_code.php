<?php
include 'sqlconnections.php';

if(isset($_REQUEST['email']))
	$email=$_REQUEST['email'];
else
	$email='null';

if(isset($_REQUEST['password']))
	$password=$_REQUEST['password'];
else
	$password='null';

$conn->set_charset("utf8mb4");

$stmt = $conn->prepare("select * from customers where email=? and password=?");
$stmt->bind_param("ss", $email,$password);
$stmt->execute();
$result = $stmt->get_result();

if($row = $result->fetch_assoc()) 
{
	$_SESSION['email']=$email;			
	echo "<script language='javascript'>alert('Login Successful');window.location='tourist/tourist_home.php';</script>";
 }
 else 
 {
	 echo "<script language='javascript'>window.location='tourist_login.php?msg=Invalid username/password';</script>";
 }
$stmt->close();
$conn->close();
?>