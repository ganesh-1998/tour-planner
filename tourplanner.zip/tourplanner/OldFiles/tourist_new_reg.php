<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body class='bg' style="background-color:#fc9cac ;background-image: url(images/11.jpg)">

<?php 
include 'menu.php';
 ?>
<div class="container" style="background-color: #ffffff;margin-top:20px;width:60%" >
  <center><h4><u><b><p style="color:red;">Tourist Registration Form</p></b></u></h4></center>
  <form name='f1' method='post' action="tourist_new_reg_code.php" enctype="multipart/form-data">
	
        
        
<div class='row'>
	<div class='col-md-5'>
		<b><label for='customer_name'>Customer Name</label></b>
		<input type='text' class='form-control' id='customer_name' placeholder='Customer Name' name='customer_name' required >
	</div>
	<div class='col-md-5'>
	<b>	<label for='address'>Address</label></b>
		<textarea rows='3' class='form-control' id='address' placeholder='Address' name='address' required ></textarea>
	</div>
</div>
<div class='row'>
	<div class='col-md-5'>
		<b><label for='zipcode'>Zip Code</label></b>
		<input type='text' class='form-control' id='zipcode' placeholder='Zipcode' name='zipcode' required >
	</div>
	<div class='col-md-5'>
	<b>	<label for='mobile'>Mobile Number</label></b>
		<input type='text' class='form-control' id='mobile' placeholder='Mobile' name='mobile' required >
	</div>
</div>
<div class='row'>
	<div class='col-md-5'>
		<b><label for='email'>E-Mail</label></b>
		<input type='email' class='form-control' id='email' placeholder='Email' name='email' required >
	</div>
	<div class='col-md-5'>
		<b><label for='pic'>Photo</label></b>
		<input type='file' class='form-control' id='pic' placeholder='Pic' name='pic' >
	</div>
</div>
<div class='row'>
	<div class='col-md-5'>
	<b>	<label for='password'>Password</label></b>
		<input type='password' class='form-control' id='password' placeholder='Password' name='password' required >
	</div>
	<div class='col-md-5'>
		<b><label for='cpassword'>Confirm-Password</label></b>
		<input type='password' class='form-control' id='cpassword' placeholder='Confirm-Password' name='cpassword' onfocusout='Validate()'required >
		</div>
		
		
	<div class="g-recaptcha" data-sitekey="6LeIURklAAAAAAthGgx3Y0535oU4f1qGys_GneW3"></div> 
		
		
</div>
   <br>
	<button type="submit" class="btn btn-default btn-success" name="register_btn" value="register">Register</button><br><br>
   </form>
</div>
		
	

</body>
</html>
