<?php 
session_start();

if (isset($_POST['register_btn'])) {
    $recaptcha = $_POST['g-recaptcha-response'];
    $secret_key = '6LeIURklAAAAAINS8JIGxSmspCoY5Cauw0zWqzku';
    $url = 'https://www.google.com/recaptcha/api/siteverify?secret='. $secret_key . '&response=' . $recaptcha;
  
    $response = file_get_contents($url);
	//print_r($response);
  
    $response = json_decode($response);
  
    if ($response->success == true) 
	{
        //echo '<script>alert("reCAPTACHA verified successfully")</script>';
    }
	else
	{
        echo "<script>alert('eCAPTACHA verified failed');window.location='tourist_new_reg.php';</script>";
		return;
    }
}
else{
	    echo "<script>alert('eCAPTACHA verified failed');window.location='tourist_new_reg.php';</script>";
		return;
}


  
 // return;



//if verfication success register 
include 'sqlconnections.php';
if(isset($_POST['customer_name']))
	$customer_name=$_POST['customer_name'];
else
	$customer_name='null';

if(isset($_POST['address']))
	$address=$_POST['address'];
else
	$address='null';

if(isset($_POST['zipcode']))
	$zipcode=$_POST['zipcode'];
else
	$zipcode='null';

if(isset($_POST['mobile']))
	$mobile=$_POST['mobile'];
else
	$mobile='null';

if(isset($_POST['email']))
	$email=$_POST['email'];
else
	$email='null';
if (!is_dir('uploads')) {mkdir('uploads');}
if(isset($_FILES['pic']))
{
	$rndno=rand();
	$pic=$rndno.$_FILES['pic']['name'];
	$errors= array();
	$file_name = $rndno.$_FILES['pic']['name'];
	$file_size =$_FILES['pic']['size'];
	$file_tmp =$_FILES['pic']['tmp_name'];
	$file_type=$_FILES['pic']['type'];
	$ss=explode('.',$_FILES['pic']['name']);
	$file_ext=strtolower($ss[count($ss)-1]);
	
if($file_size > 2097152)
{
	$errors[]='File size must be excately 2 MB';
}
if(empty($errors)==true)
{
	move_uploaded_file($file_tmp,'uploads/'.$file_name);
}
else
{

	print_r($errors);
}
}
else
	$pic='null';

if(isset($_POST['password']))
	$password=$_POST['password'];
else
	$password='null';


$registerDate=date('Y-m-d');
$conn->set_charset("utf8mb4");
$stmt = $conn->prepare("insert into customers(customer_name,address,zipcode,mobile,email,pic,password,registerDate) values(?,?,?,?,?,?,?,?)");
$stmt->bind_param("ssssssss", $customer_name,$address,$zipcode,$mobile,$email,$pic,$password,$registerDate);


if($stmt->execute())
 {
	 echo "<script language='javascript'>alert('Registration Success.');window.location='tourist_login.php';</script>";
 }
 else 
 {
	 echo "<script language='javascript'>alert('Registration failed.');window.location='tourist_new_reg.php';</script>";
}

$stmt->close();
$conn->close();

?>