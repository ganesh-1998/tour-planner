<?php
$conn = mysqli_connect('localhost', 'root', '', 'tourplannerdb');
if(! $conn ){
	die('Could not connect: ' . mysqli_error());
}
?>
