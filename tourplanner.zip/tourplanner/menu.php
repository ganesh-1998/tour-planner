<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
    
      <img src="images\l4.jpg" alt="Logo" style="width:40px;" class="rounded-pill">
      <a class="navbar-brand" href="#" ><span class='text-primary'>Tour Planner</span></a>
    </a>
  </div>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
          	        
	            <li class='nav-item'><a href='home.php' class='nav-link' class='active'>Home</a></li>	        
	            <li class='nav-item'><a href='about.php' class='nav-link' >About</a></li>	        
	            <li class='nav-item'><a href='admin_login.php' class='nav-link' >Admin</a></li>	        
	            <li class='nav-item'><a href='tourist_login.php' class='nav-link' >Tourist</a></li>	        
	            <li class='nav-item'><a href='guide_login.php' class='nav-link' >Guide</a></li> 
      </ul>
      
    </div>
  </div>
</nav>


  
