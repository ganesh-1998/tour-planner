<?php session_start(); ?>
<html lang="en">
<head>
 <?php
	include 'files/files.php';
  ?>
 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>

<?php 
include 'menu.php';
 ?>
 <br><br><br>
<div class="container card" style="background-color: #ffffff;width:30%">
    <br>
    <div class="row">
        <div class="col-sm-12 col-md- col-md-offset-12">
            <div >
			<center>
                <img src="images/ttt.jpg" style="width:40%" class="rounded-circle" alt="give image path">
				</center>
				<form name='f1' method='post' action="tourist_login_code.php" enctype="">
                
				<center>
				<h4><b><p style="color:red;">Tourist Login</p></b></h4>
				</center>
<div class='row'>
	<div class='col-md-12'>
	<b>	<label for='email'>E-Mail</label></b>
		<input type='email' class='form-control' id='email' placeholder='Enter email' name='email' required >
	</div>
</div>
<div class='row'>
	<div class='col-md-12'>
		<b><label for='password'>Password</label></b>
		<input type='password' class='form-control' id='password' placeholder='Enter password' name='password' required >
	</div>
</div>
<?php
$a=rand(1,9);
$b=rand(1,9);
$c=rand(1,9);
$ans=$a+$b-$c;
$_SESSION['ans']=''.$ans;
$question="what is $a + $b - $c ?";

?>

<div class='row'>
	<div class='col-md-12'>
		<b><label for='ans' class='text-danger'><?php echo $question;?></label></b>
		<input type='number' class='form-control' id='ans' placeholder='Enter Result' name='ans' required >
	</div>
</div>

<div class='row'>
	<div class='col-md-12'>
		<br>
		<div class="g-recaptcha" data-sitekey="6LeIURklAAAAAAthGgx3Y0535oU4f1qGys_GneW3" data-callback="verify_recaptcha"></div> 
		<span id="captcha" style="margin-left:100px;color:red" />
	</div>
</div>
				<br>
				<center>
                <button class="btn btn-lg btn-outline-secondary btn-block" type="submit" id='login' disabled>
                    Log in </button><br><br>
                <label class="checkbox">
                   <b> <a href="tourist_new_reg.php" class="text-center new-account text-primary"> New Registration </a></b>
                </label>
               </center>
                </form>
            </div>
            
			
        </div>
    </div>
	<br><center>
			<?php
if(isset($_REQUEST['msg']))
{
	 echo "<br><h3>".$_REQUEST['msg']."</h3>";
} ?>

			</center>
</div>


<script type="text/javascript">
      function verify_recaptcha() {
        const submitButton = document.getElementById("login");
        submitButton.removeAttribute("disabled");
      }

	  
    </script>
</body>
</html>