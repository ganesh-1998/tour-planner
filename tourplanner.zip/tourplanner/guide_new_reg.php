<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
</head>
<body>

<?php 
include 'menu.php';
 ?>
 <br><br><br>
<div class="container card" style="background-color: #ffffff;margin-top:20px;width:50%" ><br>
  <center><h4><u><b><p style="color:red;">Guide New Registration</p></b></u></h4></center><br>
  <form name='f1' method='post' action="guide_new_reg_code.php" enctype="multipart/form-data">
	
        
        
<div class='row'>
	<div class='col-md-6'>
		<b><label for='guide_name'>Guide Name</label></b>
		<input type='text' class='form-control' id='guide_name' placeholder='Guide Name' name='guide_name' required >
	</div>
	<div class='col-md-6'>
		<b><label for='address'>Address</label></b>
		<textarea rows='3' class='form-control' id='address' placeholder='Address' name='address' required ></textarea>
	</div>
</div>
<div class='row'>
	<div class='col-md-6'>
	<b>	<label for='mobile'>Mobile Number</label></b>
		<input type='text' class='form-control' id='mobile' placeholder='Mobile' name='mobile' required >
	</div>
	<div class='col-md-6'>
	<b>	<label for='email'>E-Mail</label></b>
		<input type='email' class='form-control' id='email' placeholder='Email' name='email' required >
	</div>
</div>
<div class='row'>
	<div class='col-md-6'>
		<b><label for='guide_pic'>Guide Pic</label></b>
		<input type='file' class='form-control' id='guide_pic' placeholder='Guide Pic' name='guide_pic' required >
	</div>
	<div class='col-md-6'>
	<b>	<label for='password'>Password</label></b>
		<input type='password' class='form-control' id='password' placeholder='Password' name='password' required >
	</div>
	<div class='col-md-6'>
		<b><label for='cpassword'>Confirm-Password</label></b>
		<input type='password' class='form-control' id='cpassword' placeholder='Confirm-Password' name='cpassword' onfocusout='Validate()'required >
		</div>
</div>
   <br>
	<button type="submit" class="btn btn-default btn-outline-secondary"> Register </button><br>
	<?php
		if(isset($_REQUEST['msg'])){
			echo "<h4 class='text-success'>".$_REQUEST['msg']."</h4>";
		}
	?>
	<br>
   </form>
</div>
		
		
</body>
</html>
