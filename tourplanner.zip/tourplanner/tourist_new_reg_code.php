<?php 
session_start();

include 'sqlconnections.php';
if(isset($_POST['customer_name']))
	$customer_name=$_POST['customer_name'];
else
	$customer_name='null';

if(isset($_POST['address']))
	$address=$_POST['address'];
else
	$address='null';

if(isset($_POST['zipcode']))
	$zipcode=$_POST['zipcode'];
else
	$zipcode='null';

if(isset($_POST['mobile']))
	$mobile=$_POST['mobile'];
else
	$mobile='null';

if(isset($_POST['email']))
	$email=$_POST['email'];
else
	$email='null';

	if(isset($_POST['password']))
	$password=$_POST['password'];
else
	$password='null';

$_SESSION['customer_name']=$customer_name;
$_SESSION['address']=$address;
$_SESSION['zipcode']=$zipcode;
$_SESSION['mobile']=$mobile;
$_SESSION['email']=$email;
$_SESSION['password']=$password;


//upload pic
if (!is_dir('uploads')) {mkdir('uploads');}
if(isset($_FILES['pic']))
{
	$rndno=rand();
	$pic=$rndno.$_FILES['pic']['name'];
	$errors= array();
	$file_name = $rndno.$_FILES['pic']['name'];
	$file_size =$_FILES['pic']['size'];
	$file_tmp =$_FILES['pic']['tmp_name'];
	$file_type=$_FILES['pic']['type'];
	$ss=explode('.',$_FILES['pic']['name']);
	$file_ext=strtolower($ss[count($ss)-1]);
	$expensions= array('jpeg','jpg','png');
	if(in_array($file_ext, $expensions)=== false)
	{
			$errors[]='extension not allowed, please choose a JPEG or PNG file.';
	} 
	if(empty($errors)==true)
	{
		move_uploaded_file($file_tmp,'uploads/'.$file_name);
	}
	else
	{
		print_r($errors);
	}
}
else
	$pic='null';

$_SESSION['pic'] = $pic;



if (isset($_POST['register_btn'])) {
    $recaptcha = $_POST['g-recaptcha-response'];
    $secret_key = '6LeIURklAAAAAINS8JIGxSmspCoY5Cauw0zWqzku';
    $url = 'https://www.google.com/recaptcha/api/siteverify?secret='. $secret_key . '&response=' . $recaptcha;
  
    $response = file_get_contents($url);
	//print_r($response);
  
    $response = json_decode($response);
  
    if ($response->success == true) 
	{
        
		echo "<script>window.location='tourist_new_reg_otp.php';</script>";
		return;
    }
	else
	{
        echo "<script>alert('Captcha failed');window.location='tourist_new_reg.php';</script>";
		return;
    }
}
else{
	    echo "<script>alert('Captcha failed');window.location='tourist_new_reg.php';</script>";
		return;
}


  
 // return;


/*
//if verfication success register 
include 'sqlconnections.php';
if(isset($_POST['customer_name']))
	$customer_name=$_POST['customer_name'];
else
	$customer_name='null';

if(isset($_POST['address']))
	$address=$_POST['address'];
else
	$address='null';

if(isset($_POST['zipcode']))
	$zipcode=$_POST['zipcode'];
else
	$zipcode='null';

if(isset($_POST['mobile']))
	$mobile=$_POST['mobile'];
else
	$mobile='null';

if(isset($_POST['email']))
	$email=$_POST['email'];
else
	$email='null';
if (!is_dir('uploads')) {mkdir('uploads');}
if(isset($_FILES['pic']))
{
	$rndno=rand();
	$pic=$rndno.$_FILES['pic']['name'];
	$errors= array();
	$file_name = $rndno.$_FILES['pic']['name'];
	$file_size =$_FILES['pic']['size'];
	$file_tmp =$_FILES['pic']['tmp_name'];
	$file_type=$_FILES['pic']['type'];
	$ss=explode('.',$_FILES['pic']['name']);
	$file_ext=strtolower($ss[count($ss)-1]);
	$expensions= array('jpeg','jpg','png');
	if(in_array($file_ext, $expensions)=== false)
	{
			$errors[]='extension not allowed, please choose a JPEG or PNG file.';
	} 
	if(empty($errors)==true)
	{
		move_uploaded_file($file_tmp,'uploads/'.$file_name);
	}
	else
	{
		print_r($errors);
	}
}
else
	$pic='null';




$registerDate=date('Y-m-d');
$conn->set_charset("utf8mb4");

$stmt = $conn->prepare("insert into customers(customer_name,address,zipcode,mobile,email,pic,password,registerDate) values(?,?,?,?,?,?,?,?)");
$stmt->bind_param("ssssssss", $customer_name,$address,$zipcode,$mobile,$email,$pic,$password,$registerDate);

if($stmt->execute())
 {
	 echo "<script language='javascript'>window.location='tourist_login.php';</script>";
 }
 else 
 {
	 echo "<script language='javascript'>window.location='tourist_new_reg.php?msg=Registraton Failed!';</script>";
}

$stmt->close();
$conn->close();*/

?>