<!DOCTYPE html>
<html lang="en">
<head>
  <?php
	include 'files/files.php';
  ?>
  <style>
   
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
	.center {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;
}
  </style>
</head>
<body class='bg' style="">

<?php 
include 'menu.php';
 ?>
<br><br><br>

<div class="container-fluid bg-3 text-center">    
   <div class="row">
    <div class="col-sm-12">
    <h2>Tour Planner</h2><br>
      <img src="images/tourhome1.jpg" class="img-responsive center" style="width:50%" alt="Image" >
    </div>
   
  </div>
</div><br>


</body>
</html>
