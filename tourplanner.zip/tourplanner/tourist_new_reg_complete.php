<?php 
session_start();

include 'sqlconnections.php';

$customer_name=$_SESSION['customer_name'];
$address=$_SESSION['address'];
$zipcode=$_SESSION['zipcode'];
$mobile=$_SESSION['mobile'];
$email=$_SESSION['email'];
$password=$_SESSION['password'];
$pic=$_SESSION['pic'];


$registerDate=date('Y-m-d');
$conn->set_charset("utf8mb4");

$stmt = $conn->prepare("insert into customers(customer_name,address,zipcode,mobile,email,pic,password,registerDate) values(?,?,?,?,?,?,?,?)");
$stmt->bind_param("ssssssss", $customer_name,$address,$zipcode,$mobile,$email,$pic,$password,$registerDate);

if($stmt->execute())
 {
	 echo "<script language='javascript'>window.alert('Registration success');window.location='tourist_login.php';</script>";
 }
 else 
 {
	 echo "<script language='javascript'>window.location='tourist_new_reg.php?msg=Registraton Failed!';</script>";
}

$stmt->close();
$conn->close();

?>