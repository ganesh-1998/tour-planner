<?php
include 'sqlconnections.php';
if(isset($_REQUEST['username']))
	$username=$_REQUEST['username'];
else
	$username='null';

if(isset($_REQUEST['password']))
	$password=$_REQUEST['password'];
else
	$password='null';

$conn->set_charset("utf8mb4");
$qry="select * from admin where username=? and password=?";
$stmt =$conn->prepare($qry);
$stmt->bind_param("ss",$username,$password);
$stmt->execute();
$rs = $stmt->get_result();

if($row = mysqli_fetch_assoc($rs))
{
	echo "<script language='javascript'>window.location='admin/admin_main.php';</script>";
}
else 
{
	 echo "<script language='javascript'>window.location='admin_login.php?msg=Invalid username/password';</script>";
}
$stmt->close();
mysqli_close($conn);
?>