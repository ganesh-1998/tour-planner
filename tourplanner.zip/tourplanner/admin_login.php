<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
   <?php
	include 'files/files.php';
  ?>
</head>
<body class='bg' style="">

<?php 
include 'menu.php';
 ?><br><br><br><br><br>
<div class="container card" style="background-color: #ffffff;width:40%">
  
  <form name='f1' method='post' action="admin_login_code.php" enctype="">
	
        <div class="row">
			<div class="col-sm-6">
				<br>
				<img src='images/adm.jpg' width='100%' height='60%'>
			</div>
			<div class="col-sm-6"><br>
				<h4><b><p style="color:red;">Admin Login</p></b></h4>
				
<div class='row'>
	<div class='col-md-12'>
		<b><label for='username'>User Name</label></b>
		<input type='text' class='form-control' id='username' placeholder='Enter username' name='username' required >
	</div>
</div>
<div class='row'>
	<div class='col-md-12'>
		<b><label for='password'>Password</label></b>
		<input type='password' class='form-control' id='password' placeholder='Enter password' name='password' required >
	</div>
</div>
				
				<br>
				<button type="submit" class="btn btn-outline-secondary">Login</button><br>
				<br>
   
				<?php
if(isset($_REQUEST['msg']))
{
	 echo '<br><h2>Invalid Username/Password</h2>';
} ?>

			</div>
		</div>	
		
  
   </form>


		
		
</body>
</html>
