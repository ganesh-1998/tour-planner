<?php 
session_start();
include 'sqlconnections.php';
if(isset($_REQUEST['guide_name']))
	$guide_name=$_REQUEST['guide_name'];
else
	$guide_name='null';

if(isset($_REQUEST['address']))
	$address=$_REQUEST['address'];
else
	$address='null';

if(isset($_REQUEST['mobile']))
	$mobile=$_REQUEST['mobile'];
else
	$mobile='null';

if(isset($_REQUEST['email']))
	$email=$_REQUEST['email'];
else
	$email='null';
if (!is_dir('uploads')) {mkdir('uploads');}

if(isset($_FILES['guide_pic']))
{
	$rndno=rand();
	$guide_pic=$rndno.$_FILES['guide_pic']['name'];

	$errors= array();
	$file_name = $rndno.$_FILES['guide_pic']['name'];
	$file_size =$_FILES['guide_pic']['size'];
	$file_tmp =$_FILES['guide_pic']['tmp_name'];
	$file_type=$_FILES['guide_pic']['type'];
	$ss=explode('.',$_FILES['guide_pic']['name']);
	$file_ext=strtolower($ss[count($ss)-1]);
	
	$file_ext=strtolower(end(explode('.',$_FILES['guide_pic']['name']))); 
	$expensions= array('jpeg','jpg','png');
	if(in_array($file_ext, $expensions)=== false)
	{
			$errors[]='extension not allowed, please choose a JPEG or PNG file.';
	} 
	if(empty($errors)==true)
	{
		move_uploaded_file($file_tmp,'uploads/'.$file_name);
	}
	else
	{
		print_r($errors);
	}
}
else
	$guide_pic='null';


if(isset($_REQUEST['password']))
	$password=$_REQUEST['password'];
else
	$password='null';

$qry="insert into guides(guide_name,address,mobile,email,guide_pic,password) values(?,?,?,?,?,?)";
$stmt =$conn->prepare($qry);
$stmt->bind_param("ssssss", $guide_name, $address, $mobile, $email, $guide_pic, $password );
$stmt->execute();
if($stmt->affected_rows > 0)
{
	echo "<script language='javascript'>alert('Registration Success.');window.location='guide/guide_home_main.php';</script>";
}
else 
{
	echo "<script language='javascript'>alert('Registration Success.');window.location='guide_new_reg.php?msg=Registration Failed!';</script>";
}
mysqli_close($conn);
?>